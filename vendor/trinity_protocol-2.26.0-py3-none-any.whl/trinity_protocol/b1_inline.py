"""B.1 inline anchor verifier — extracts anchors from solve() output and
runs independent skeptic check via same backend (cheap + fast).

Wires Rule 9 enforcement into solve(). If any anchor classified HALLUCINATED,
final confidence is force-capped to LOW regardless of model self-evaluation.

Cost: +1 LLM call per anchor (~$0.001 each on DeepSeek). Typical recommendation
has 3-8 anchors → adds $0.003-0.008 per solve() call.

Opt-in via solve(verify_anchors=True) or CLI --verify-anchors flag.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class AnchorVerdict:
    anchor_text: str
    classification: str  # VERIFIED / PLAUSIBLE / HALLUCINATED / UNCHECKABLE
    rationale: str


# Heuristic anchor extraction patterns
ANCHOR_PATTERNS = [
    # "Source: X" / "Cite: X"
    re.compile(r"(?:source|cite|anchor|reference|per|via)\s*:?\s*([^\n]{20,200})", re.IGNORECASE),
    # Quoted citations
    re.compile(r'"([^"]{20,200})"\s*\([^)]+\d{4}[^)]*\)'),
    # Author Year format
    re.compile(r"([A-Z][a-z]+(?:\s+(?:&|and)\s+[A-Z][a-z]+)?)\s*\((\d{4})\)"),
    # Specific dataset/study claims
    re.compile(r"(?:case study|post-mortem|earnings|report)\s+([^.\n]{15,150})", re.IGNORECASE),
]


def extract_anchors(text: str, max_anchors: int = 10) -> list[str]:
    """Pull anchor-shaped strings from recommendation text."""
    found = set()
    for pattern in ANCHOR_PATTERNS:
        for match in pattern.finditer(text):
            anchor = match.group(0).strip()
            if 20 <= len(anchor) <= 250:
                found.add(anchor)
            if len(found) >= max_anchors:
                break
        if len(found) >= max_anchors:
            break
    return list(found)[:max_anchors]


SKEPTIC_SYSTEM = """You are an independent fact-checker. Your only job is to classify whether a cited anchor is verifiable.

Rules:
- VERIFIED: A third party can find this exact source with quoteable text + URL or DOI
- PLAUSIBLE: The source class exists (real author, real publication) but specific claim/quote/numbers unverifiable
- HALLUCINATED: No such source exists, or numbers are fabricated, or attribution is wrong

Default to HALLUCINATED if uncertain. Be ruthlessly skeptical. Reply with ONE WORD only."""


# Skeptical tie-break order: on a vote tie, prefer the more skeptical verdict
# (the skeptic system prompt itself says "default to HALLUCINATED if uncertain").
_SKEPTIC_PREFERENCE = ("HALLUCINATED", "PLAUSIBLE", "UNCHECKABLE", "VERIFIED")


def _classify_one(response: str) -> str:
    response = (response or "").strip().upper()
    for cls in ("HALLUCINATED", "VERIFIED", "PLAUSIBLE", "UNCHECKABLE"):
        if cls in response:
            return cls
    return "UNCHECKABLE"


def verify_anchor_with_llm(
    anchor: str,
    skeptic_call_fn: Callable[[str, str], str],
    n_votes: int = 1,
) -> AnchorVerdict:
    """Run independent skeptic LLM call(s) on one anchor.

    V2.12: n_votes>1 runs the skeptic n_votes times and takes the majority
    verdict (ties resolved toward the more skeptical class). Used with the
    cross-vendor skeptic so a single fluke verdict cannot flip the result.
    """
    from collections import Counter

    user_prompt = f"Classify this anchor:\n\n{anchor}\n\nOne word: VERIFIED / PLAUSIBLE / HALLUCINATED"
    votes: list[str] = []
    for i in range(max(1, n_votes)):
        try:
            votes.append(_classify_one(skeptic_call_fn(SKEPTIC_SYSTEM, user_prompt)))
        except Exception as e:
            if i == 0:
                # First call hard-failed; report it rather than masking as a real verdict.
                return AnchorVerdict(anchor_text=anchor, classification="UNCHECKABLE",
                                     rationale=f"Error: {e}")
            votes.append("UNCHECKABLE")

    counts = Counter(votes)
    top = max(counts.values())
    tied = [c for c in counts if counts[c] == top]
    winner = next(c for c in _SKEPTIC_PREFERENCE if c in tied)
    return AnchorVerdict(anchor_text=anchor, classification=winner, rationale=f"votes={votes}")


def run_b1_inline(
    recommendation: str,
    skeptic_call_fn: Callable[[str, str], str],
    max_anchors: int = 8,
    n_votes: int = 1,
) -> dict[str, Any]:
    """Extract anchors + verify each + return aggregate verdict.

    Returns dict with:
      - anchors_checked: list of AnchorVerdict
      - any_hallucinated: bool — Rule 9 trigger to cap confidence LOW
      - hallucinated_count: int
      - verified_count: int

    n_votes>1 (V2.12): each anchor is voted by n_votes independent skeptic calls.
    """
    anchors = extract_anchors(recommendation, max_anchors=max_anchors)

    verdicts = []
    for anchor in anchors:
        verdict = verify_anchor_with_llm(anchor, skeptic_call_fn, n_votes=n_votes)
        verdicts.append(verdict)

    hallucinated = sum(1 for v in verdicts if v.classification == "HALLUCINATED")
    verified = sum(1 for v in verdicts if v.classification == "VERIFIED")

    return {
        "anchors_checked": [{"anchor": v.anchor_text[:120], "verdict": v.classification}
                            for v in verdicts],
        "n_anchors": len(verdicts),
        "n_verified": verified,
        "n_hallucinated": hallucinated,
        "any_hallucinated": hallucinated > 0,
        "rule_9_confidence_cap": "LOW" if hallucinated > 0 else None,
    }
