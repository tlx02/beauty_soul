"""V2.8 beta — Test-Time Compute (TTC) Scaling Module.

Implements N-round sampling + AW-vote convergence until confidence stable.
Per Snell et al. 2024 "Scaling LLM Test-Time Compute Optimally" + OpenAI o1
system card + DeepSeek R1 architecture.

Design (V2.8 beta per experiments/47):
    1. Run V2.7 1.0 stack N times with stochastic variation (temperature)
    2. AW critic scores each round
    3. Convergence detected when AW variance < 1 across last 3 rounds
    4. Early exit if first round AW >= 9 (problem is easy)
    5. Hard cap N=20 (cost runaway prevention)
    6. Returns best (highest-AW) recommendation across rounds

Predicted lift: +0.5-1pp W-L-T on n=1000 (NFL-capped — V2.7 1.0 already at
98.1%, NFL floor 97-98%, so gain is marginal).

NOT YET DEPLOYED in solve() default path — opt-in via solve(..., ttc=True).
"""

from __future__ import annotations

import statistics
import sys
from dataclasses import dataclass, asdict
from typing import Any, Callable

from .creative import auto_score
from .v26_integration import integrate_v26


# Convergence parameters (per Snell 2024 + empirical calibration)
EARLY_EXIT_AW_THRESHOLD = 9        # AW score >= 9 first round → done
CONVERGENCE_VARIANCE_THRESHOLD = 1.0  # AW variance across last 3 < 1 → stable
DEFAULT_MAX_N = 20                  # Hard cap rounds (cost runaway prevention)
DEFAULT_MIN_N = 3                   # Minimum rounds for convergence detection
DEFAULT_TEMPERATURES = [0.0, 0.7, 1.0]  # Stochastic variation across rounds


@dataclass
class TTCResult:
    """TTC scaling round-by-round trace + final converged answer."""
    rounds_run: int
    converged: bool
    convergence_reason: str  # "early_exit" / "variance_stable" / "max_cap"
    best_round_aw_score: int
    best_round_index: int
    best_recommendation: str
    aw_scores_per_round: list[int]
    confidence: str
    total_cost_usd: float

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def detect_convergence(aw_scores: list[int], min_n: int) -> tuple[bool, str]:
    """Check if AW scores have converged.

    Returns (converged: bool, reason: str).
    """
    if len(aw_scores) < min_n:
        return False, "insufficient_rounds"

    # Early exit: first round AW >= threshold = problem was easy
    if len(aw_scores) >= 1 and aw_scores[0] >= EARLY_EXIT_AW_THRESHOLD:
        return True, "early_exit_high_aw"

    # Variance stable across last 3 rounds
    last_3 = aw_scores[-3:]
    if len(last_3) == 3:
        try:
            variance = statistics.variance(last_3)
            if variance < CONVERGENCE_VARIANCE_THRESHOLD:
                return True, "variance_stable"
        except statistics.StatisticsError:
            pass

    return False, "still_searching"


def run_ttc(
    problem: str,
    domain: str = "",
    solver_fn: Callable[[str, str, dict], dict] | None = None,
    max_n: int = DEFAULT_MAX_N,
    min_n: int = DEFAULT_MIN_N,
    temperatures: list[float] | None = None,
    verbose: bool = False,
) -> TTCResult:
    """Run V2.8 beta TTC scaling on a problem.

    Args:
        problem: The problem to solve
        domain: Optional domain context for V2.6 integration
        solver_fn: Function (problem, domain, kwargs) -> {final, aw_score, cost_usd}
                   Defaults to a wrapper around trinity_protocol.solve().
        max_n: Hard cap on rounds (cost protection)
        min_n: Minimum rounds before convergence check
        temperatures: List of temperatures to cycle through (stochastic variation)
        verbose: Print per-round trace

    Returns:
        TTCResult with round-by-round trace + converged best answer.
    """
    if temperatures is None:
        temperatures = DEFAULT_TEMPERATURES

    if solver_fn is None:
        solver_fn = _default_solver_wrapper

    round_outputs = []
    aw_scores = []
    total_cost = 0.0

    for n in range(max_n):
        temp = temperatures[n % len(temperatures)]
        if verbose:
            print(f"[TTC] round {n+1}/{max_n} (temp={temp})", file=sys.stderr, flush=True)

        try:
            round_result = solver_fn(problem, domain, {"temperature": temp})
        except Exception as e:
            if verbose:
                print(f"[TTC] round {n+1} FAILED: {e}", file=sys.stderr)
            continue

        round_outputs.append(round_result)
        aw_scores.append(round_result.get("aw_score", 0))
        total_cost += round_result.get("cost_usd", 0.0)

        if verbose:
            print(f"[TTC] round {n+1} AW={aw_scores[-1]}, cost=${total_cost:.4f}", file=sys.stderr)

        # Convergence detection
        converged, reason = detect_convergence(aw_scores, min_n)
        if converged:
            if verbose:
                print(f"[TTC] CONVERGED at round {n+1}: {reason}", file=sys.stderr)
            return _build_result(round_outputs, aw_scores, total_cost, n+1, True, reason)

    # Max cap hit
    if verbose:
        print(f"[TTC] MAX CAP {max_n} reached without variance stability", file=sys.stderr)
    return _build_result(round_outputs, aw_scores, total_cost, max_n, False, "max_cap")


def _default_solver_wrapper(problem: str, domain: str, kwargs: dict) -> dict:
    """Wrap trinity_protocol.solve() returning dict with aw_score + cost_usd."""
    # Import inside to avoid circular dependency at module load
    from . import solve as base_solve

    result = base_solve(
        problem,
        domain=domain,
        verbose=False,
        return_dict=True,
        max_tokens=2048,
    )
    return result


def _build_result(
    outputs: list[dict],
    aw_scores: list[int],
    total_cost: float,
    rounds_run: int,
    converged: bool,
    reason: str,
) -> TTCResult:
    """Pick the round with highest AW score as final answer."""
    if not outputs:
        return TTCResult(
            rounds_run=0, converged=False, convergence_reason="no_rounds_completed",
            best_round_aw_score=0, best_round_index=-1,
            best_recommendation="", aw_scores_per_round=[],
            confidence="UNKNOWN", total_cost_usd=0.0,
        )

    best_idx = max(range(len(aw_scores)), key=lambda i: aw_scores[i])
    best = outputs[best_idx]

    # Aggregate confidence: highest if converged + best AW >= 9
    if converged and aw_scores[best_idx] >= 9:
        confidence = "HIGH"
    elif converged and aw_scores[best_idx] >= 7:
        confidence = "MODERATE"
    elif aw_scores[best_idx] >= 5:
        confidence = "LOW"
    else:
        confidence = "UNKNOWN"

    return TTCResult(
        rounds_run=rounds_run,
        converged=converged,
        convergence_reason=reason,
        best_round_aw_score=aw_scores[best_idx],
        best_round_index=best_idx,
        best_recommendation=best.get("final", ""),
        aw_scores_per_round=aw_scores,
        confidence=confidence,
        total_cost_usd=total_cost,
    )


# ============================================================
# CLI
# ============================================================

def main() -> int:
    import argparse
    import json
    parser = argparse.ArgumentParser(description="V2.8 beta — Test-Time Compute Scaling")
    parser.add_argument("problem", help="Problem to solve with TTC scaling")
    parser.add_argument("--domain", default="")
    parser.add_argument("--max-n", type=int, default=DEFAULT_MAX_N)
    parser.add_argument("--min-n", type=int, default=DEFAULT_MIN_N)
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    result = run_ttc(
        args.problem, domain=args.domain,
        max_n=args.max_n, min_n=args.min_n,
        verbose=args.verbose,
    )
    print(json.dumps(result.as_dict(), indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
