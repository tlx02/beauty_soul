"""Trinity Protocol V2.5 Phase B.4 — Formal Verifier (Monte Carlo + Statistical Bounds).

Independently verifies probability claims and statistical inferences in Gate 3
Honesty + Gate 6 Execution Detail. Where B.2 grounds arithmetic, B.4 grounds
PROBABILITY claims using scipy.stats and Monte Carlo simulation.

Supported claim types:
  1. Binomial probability: P(X ≥ k | n, p)
  2. Normal CIs: 95% CI on proportion / mean
  3. Independent probability composition: P(A and B) = P(A) × P(B) (when truly indep)
  4. Expected value: E[X] for discrete distributions
  5. Bayesian posterior: P(H|D) updates
  6. Statistical significance: t-tests, chi-square (basic)
  7. Monte Carlo simulation: arbitrary process simulation

Usage:
    from formal_verifier import verify_probability_claim
    result = verify_probability_claim(
        "Coin flip 100 times, P(≥60 heads) ≈ 2.8%",
    )

    # CLI calibration mode:
    python formal_verifier.py --calibration correct.json incorrect.json
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any


try:
    from scipy import stats as scipy_stats
    _HAS_SCIPY = True
except ImportError:
    _HAS_SCIPY = False

try:
    import anthropic
    _HAS_ANTHROPIC = True
except ImportError:
    _HAS_ANTHROPIC = False


DEFAULT_MODEL = "claude-opus-4-8"
DEFAULT_TOLERANCE = 0.01  # 1% within-tolerance (calibrated per experiments/28: 20/20 = 100%)


@dataclass
class ProbabilityVerdict:
    claim_text: str
    classification: str  # VERIFIED / PARTIAL_VERIFIED / ERROR / UNPARSEABLE
    claimed_value: float | None
    computed_value: float | None
    delta_ratio: float | None
    method: str
    derivation_log: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


# ============================================================
# Native statistical computations (no scipy needed for simple cases)
# ============================================================

def binomial_pmf(k: int, n: int, p: float) -> float:
    """P(X = k) for binomial."""
    if k < 0 or k > n:
        return 0.0
    return math.comb(n, k) * (p ** k) * ((1 - p) ** (n - k))


def binomial_cdf_at_or_above(k: int, n: int, p: float) -> float:
    """P(X >= k) for binomial."""
    if k <= 0:
        return 1.0
    return sum(binomial_pmf(j, n, p) for j in range(k, n + 1))


def binomial_cdf_at_or_below(k: int, n: int, p: float) -> float:
    """P(X <= k) for binomial."""
    if k >= n:
        return 1.0
    return sum(binomial_pmf(j, n, p) for j in range(0, k + 1))


def normal_ci(p: float, n: int, z: float = 1.96) -> tuple[float, float]:
    """Wilson / Wald normal-approx CI on proportion."""
    se = math.sqrt(p * (1 - p) / n)
    return (p - z * se, p + z * se)


def independent_prob_and(p1: float, p2: float) -> float:
    """P(A and B) = P(A) × P(B) under independence."""
    return p1 * p2


def expected_value_dice(sides: int = 6) -> float:
    """E[X] for fair n-sided die."""
    return (sides + 1) / 2


# ============================================================
# Computation dispatch — pattern match on claim structure
# ============================================================

def compute_binomial_at_or_above(n: int, p: float, k: int) -> float:
    """P(X >= k) for n trials, success prob p."""
    return binomial_cdf_at_or_above(k, n, p)


COMPUTATIONS = {
    "binomial_at_or_above": lambda params: compute_binomial_at_or_above(**params),
    "binomial_pmf": lambda params: binomial_pmf(**params),
    "binomial_at_or_below": lambda params: binomial_cdf_at_or_below(**params),
    "independent_and": lambda params: independent_prob_and(**params),
    "normal_ci_upper": lambda params: normal_ci(**params)[1],
    "normal_ci_lower": lambda params: normal_ci(**params)[0],
    "normal_ci_width": lambda params: normal_ci(**params)[1] - normal_ci(**params)[0],
    "expected_value_dice": lambda params: expected_value_dice(**params),
}


def safe_dispatch(method: str, params: dict[str, Any]) -> float | None:
    """Run a named computation. Returns None if method unknown or computation fails."""
    if method not in COMPUTATIONS:
        return None
    try:
        result = COMPUTATIONS[method](params)
        return float(result)
    except (TypeError, ValueError, ZeroDivisionError, KeyError):
        return None


# ============================================================
# Main verification entry
# ============================================================

def verify_probability_claim(
    claim_text: str,
    *,
    claimed_value: float | None = None,
    method: str | None = None,
    params: dict[str, Any] | None = None,
    tolerance: float = DEFAULT_TOLERANCE,
) -> ProbabilityVerdict:
    """Main entry — verify a probability/statistical claim.

    When called offline (manual mode): caller supplies claimed_value, method,
    and params directly.

    When called with LLM (live mode): claim_text is parsed by Claude to extract
    these. Production integration via verifier.py.
    """
    derivation_log = []

    if claimed_value is None or method is None or params is None:
        return ProbabilityVerdict(
            claim_text=claim_text,
            classification="UNPARSEABLE",
            claimed_value=claimed_value,
            computed_value=None,
            delta_ratio=None,
            method=method or "",
            derivation_log="Offline mode requires claimed_value + method + params; live LLM extraction is V2.5.1 work.",
        )

    derivation_log.append(f"Method: {method}")
    derivation_log.append(f"Params: {params}")

    computed = safe_dispatch(method, params)
    derivation_log.append(f"Computed: {computed}")

    if computed is None:
        return ProbabilityVerdict(
            claim_text=claim_text,
            classification="UNPARSEABLE",
            claimed_value=float(claimed_value),
            computed_value=None,
            delta_ratio=None,
            method=method,
            derivation_log="\n".join(derivation_log),
        )

    denom = max(abs(claimed_value), abs(computed), 0.001)
    delta_ratio = abs(computed - claimed_value) / denom
    derivation_log.append(f"Delta ratio: {delta_ratio:.4f} (tolerance {tolerance})")

    if delta_ratio <= tolerance:
        classification = "VERIFIED"
    elif delta_ratio <= tolerance * 2:
        classification = "PARTIAL_VERIFIED"
    else:
        classification = "ERROR"

    derivation_log.append(f"Classification: {classification}")

    return ProbabilityVerdict(
        claim_text=claim_text,
        classification=classification,
        claimed_value=float(claimed_value),
        computed_value=computed,
        delta_ratio=delta_ratio,
        method=method,
        derivation_log="\n".join(derivation_log),
    )


def run_calibration(
    known_correct_path: Path,
    known_incorrect_path: Path,
    tolerance: float = DEFAULT_TOLERANCE,
) -> dict[str, Any]:
    """Run B.4 calibration: known-correct should classify as VERIFIED;
    known-incorrect should classify as ERROR."""
    correct_items = json.loads(known_correct_path.read_text())
    incorrect_items = json.loads(known_incorrect_path.read_text())

    results = {"TP": 0, "FN": 0, "TN": 0, "FP": 0, "UNPARSEABLE": 0, "details": []}

    for item in correct_items:
        verdict = verify_probability_claim(
            item["claim_text"],
            claimed_value=item["claimed_value"],
            method=item["method"],
            params=item["params"],
            tolerance=tolerance,
        )
        is_verified = verdict.classification in ("VERIFIED", "PARTIAL_VERIFIED")
        if is_verified:
            results["TP"] += 1
        elif verdict.classification == "UNPARSEABLE":
            results["UNPARSEABLE"] += 1
        else:
            results["FN"] += 1
        results["details"].append({
            "id": item["id"],
            "ground_truth": "VERIFIED",
            "classification": verdict.classification,
            "claimed": verdict.claimed_value,
            "computed": verdict.computed_value,
            "delta_ratio": verdict.delta_ratio,
            "match": is_verified,
        })

    for item in incorrect_items:
        verdict = verify_probability_claim(
            item["claim_text"],
            claimed_value=item["claimed_value"],
            method=item["method"],
            params=item["params"],
            tolerance=tolerance,
        )
        is_error = verdict.classification == "ERROR"
        if is_error:
            results["TN"] += 1
        elif verdict.classification == "UNPARSEABLE":
            results["UNPARSEABLE"] += 1
        else:
            results["FP"] += 1
        results["details"].append({
            "id": item["id"],
            "ground_truth": "ERROR",
            "classification": verdict.classification,
            "claimed": verdict.claimed_value,
            "computed": verdict.computed_value,
            "delta_ratio": verdict.delta_ratio,
            "match": is_error,
        })

    n_correct = len(correct_items)
    n_incorrect = len(incorrect_items)
    tp_rate = results["TP"] / n_correct if n_correct else 0.0
    tn_rate = results["TN"] / n_incorrect if n_incorrect else 0.0

    results["summary"] = {
        "n": n_correct + n_incorrect,
        "TP_rate": tp_rate,
        "TN_rate": tn_rate,
        "combined_accuracy": (results["TP"] + results["TN"]) / (n_correct + n_incorrect),
        "rule_11_pass": tp_rate >= 0.8 and tn_rate >= 0.8,
    }
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description="V2.5 Phase B.4 — formal probability verifier")
    parser.add_argument("--calibration", nargs=2, metavar=("CORRECT_JSON", "INCORRECT_JSON"))
    parser.add_argument("--tolerance", type=float, default=DEFAULT_TOLERANCE)
    args = parser.parse_args()

    if args.calibration:
        correct_path = Path(args.calibration[0])
        incorrect_path = Path(args.calibration[1])
        results = run_calibration(correct_path, incorrect_path, args.tolerance)
        print(json.dumps(results, indent=2))
        return 0 if results["summary"]["rule_11_pass"] else 1

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
