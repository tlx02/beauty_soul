"""V2.25 Interactive — bidirectional clarify loop on top of V2.24.

V2.24 is one-shot: problem → adaptive dispatch → answer. Real problems often omit
the one fact that decides the answer (who the user is, the real goal, the binding
constraint, the resource at hand). This module adds a FRONT clarify gate: before
answering, judge whether a missing fact would CHANGE the recommendation; if so,
ask the 1-3 highest-leverage questions, take the answers, then re-solve with the
enriched context via the normal V2.24 path.

Design discipline (from exp/83): asking is the mirror of the framework's
over-challenge tendency. The gate must be ASYMMETRIC — fire ONLY when an answer
would flip or materially change the recommendation, NOT merely "more detail would
be nice". A self-sufficient prompt must pass through clean (NONE), or the loop is
pure friction. This composes with — does not replace — the pseudo discipline: for
a pseudo (XY) question, the redirect to the real problem still happens; clarify
asks only about facts that change which real problem we're solving.
"""
from __future__ import annotations
import re

_CLARIFY_SYS = """你是决策顾问的"信息充分性"前置判官。判断这个问题该不该先反问澄清。

先分两类:
【A 开放求建议且对象/目标/约束未说】——"该不该做X""帮我设计/规划Y""怎么提高/优化Z"这类, 而且【用户是谁+什么场景 / 真实目标(增长vs利润vs留存vs退出) / 硬约束(预算/跑道/团队/合规/已有资源)】里至少一项没讲清。这类几乎总要先问, 因为不同取值会翻转建议(同一个"该不该做App", 桌面端B2B客户=不做, 移动端C端=可能做)。→ 必须提问。
【B 已能定方向】——以下一律【不问】, 直接输出 NONE:
  - 要算一个数(毛利率/涨跌幅/概率)
  - 题面已有事实直接决定答案(违法/算术矛盾/已确认数据/合同硬条款)——例如"法务认定违规该不该发"答案就是不发, 不要问
  - 已点名了具体待评估对象且信息够判(该不该删这个零调用的API)

A 类提问规则: 问 1-3 个【答了会翻转建议】的高杠杆问题, 通常就是: 你的用户/客户是谁、在什么场景用? 你真正想达成的目标是什么? 有什么硬约束或已有资源? 不要问执行细节、不要问"锦上添花"。
**伪问题特例**: 用户已锁定一个具体补救解法但真问题可能在上游时, 不要问那个解法的执行细节, 只问"能帮确定真问题"的事实。

输出: A 类每行一个问题以 "Q: " 开头(≤3行, 不解释); B 类只输出 NONE。"""


def clarify_gate(problem: str, call_fn) -> list:
    """Return up to 3 high-leverage clarifying questions, or [] if the problem is
    answerable as-is. call_fn(system, user) -> str. One cheap call (~$0.0005)."""
    try:
        out = call_fn(_CLARIFY_SYS, problem) or ""
    except Exception:
        return []  # fail-open: on any error, behave like one-shot (no clarify)
    if re.search(r"\bNONE\b", out) and "Q:" not in out:
        return []
    qs = [m.group(1).strip() for m in re.finditer(r"^\s*Q[:：]\s*(.+)$", out, re.MULTILINE)]
    return qs[:3]


def build_enriched_problem(problem: str, qa_pairs: list) -> str:
    """Fold clarify Q&A back into the problem for the V2.24 re-solve.
    qa_pairs: list of (question, answer). Skips unanswered/empty answers.

    V2.26 (exp/86): a REFRAME MANDATE. V2.25 just appended the facts and asked for
    "a final answer", so the original ask's framing anchored the re-solve — the
    clarification surfaced the flipping fact but the answer kept optimizing the
    wrong thing (held-out 3/3 interactive failures were all this). V2.26 forces the
    re-solve to FIRST re-judge whether the clarified facts changed WHICH problem to
    solve, and pivot if so. Lifts interactive 5/8 → 8/8 (original held-out) / 5/8 →
    7/8 (clean held-out on novel scenario types — generalizes, not example-fitting).
    No ask-rate tradeoff: this is re-solve enrichment, the clarify gate is untouched.
    """
    answered = [(q, a) for q, a in qa_pairs if a and a.strip()]
    if not answered:
        return problem
    lines = "\n".join(f"- 问: {q}\n  答: {a.strip()}" for q, a in answered)
    return (f"{problem}\n\n═══ 已澄清的关键事实(用户答复)═══\n{lines}\n\n"
            f"═══ 先重判问题, 再作答(V2.26)═══\n"
            f"这些澄清的事实可能改变了'真正该解决的问题'。**第一步先用一行判断**: "
            f"基于这些事实, 用户最初的问法还是对的问题, 还是真问题其实在别处?\n"
            f"- 若真问题变了 → 明确点破真问题, 然后解决真问题, 不要顺着最初问法答。"
            f"(例: 问'怎么优化定价'但事实是客户集中度风险; 问'该做X吗'但事实显示阶段太早根本不该现在做; "
            f"问'怎么扩份额'但事实是市场在萎缩该考虑转型)\n"
            f"- 若最初问法仍成立 → 直接基于澄清事实给最 actionable 的答案。\n"
            f"不要在已被事实推翻的框架内优化。")
