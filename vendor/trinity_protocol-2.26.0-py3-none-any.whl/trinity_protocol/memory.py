"""V2.5 Phase B.3.1 — Sentence-Embedding Upgraded Anchor Memory.

Drop-in replacement for anchor_memory.py with sentence-transformer + cosine
similarity instead of SequenceMatcher. Same API, better retrieval on
paraphrased queries.

Predicted gain: ~90% (SequenceMatcher) → ~95%+ (semantic embeddings).

Model: all-MiniLM-L6-v2 (80MB, fast, multilingual-capable sentence embeddings).
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any

try:
    from sentence_transformers import SentenceTransformer
    import numpy as np
    _HAS_SBERT = True
except ImportError:
    _HAS_SBERT = False

# Import data classes from V1
sys.path.insert(0, str(Path(__file__).parent))
from anchor_memory import CachedAnchor, LookupResult, DEFAULT_CACHE_PATH


DEFAULT_MODEL = "all-MiniLM-L6-v2"
DEFAULT_SIMILARITY = 0.50  # cosine similarity threshold (calibrated below)


class AnchorMemoryV2:
    """Embedding-based anchor cache with cosine-similarity retrieval."""

    def __init__(
        self,
        cache_path: Path = DEFAULT_CACHE_PATH,
        similarity_threshold: float = DEFAULT_SIMILARITY,
        model_name: str = DEFAULT_MODEL,
    ):
        if not _HAS_SBERT:
            raise ImportError("Requires sentence-transformers. Install: pip install sentence-transformers")
        self.cache_path = cache_path
        self.similarity_threshold = similarity_threshold
        self.model = SentenceTransformer(model_name)
        self.cache: list[CachedAnchor] = []
        self.embeddings = None  # numpy array of cached anchor embeddings
        self._load()

    def _load(self) -> None:
        if not self.cache_path.exists():
            self.cache = []
            return
        try:
            data = json.loads(self.cache_path.read_text())
            self.cache = [CachedAnchor(**item) for item in data.get("anchors", [])]
            if self.cache:
                texts = [f"{a.source} | {a.datum}" for a in self.cache]
                self.embeddings = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
        except (json.JSONDecodeError, TypeError):
            self.cache = []

    def lookup(self, source: str, datum: str) -> LookupResult:
        """Cosine-similarity lookup."""
        if not self.cache or self.embeddings is None:
            return LookupResult(
                source=source, datum=datum,
                classification="UNCACHED",
                cache_hit=False,
                similarity_score=0.0,
            )

        query_text = f"{source} | {datum}"
        query_emb = self.model.encode([query_text], convert_to_numpy=True, show_progress_bar=False)[0]

        # Cosine similarity
        norms = np.linalg.norm(self.embeddings, axis=1) * np.linalg.norm(query_emb)
        dots = self.embeddings @ query_emb
        cosines = dots / (norms + 1e-10)
        best_idx = int(np.argmax(cosines))
        best_score = float(cosines[best_idx])
        best_match = self.cache[best_idx]

        if best_score >= self.similarity_threshold:
            return LookupResult(
                source=source, datum=datum,
                classification=best_match.classification,
                cache_hit=True,
                similarity_score=best_score,
                matched_cached_source=best_match.source,
                evidence=best_match.evidence,
                notes=f"matched cached {best_match.verifier_id} via cosine similarity",
            )

        return LookupResult(
            source=source, datum=datum,
            classification="UNCACHED",
            cache_hit=False,
            similarity_score=best_score,
            matched_cached_source=best_match.source,
            notes="best cosine match below threshold; needs fresh B.1 verification",
        )


def run_benchmark(memory: AnchorMemoryV2, benchmark_path: Path) -> dict[str, Any]:
    """Run B.3.1 acceptance benchmark."""
    benchmark = json.loads(benchmark_path.read_text())
    results = {"hit_correct_class": 0, "hit_wrong_class": 0, "miss_expected_miss": 0, "miss_expected_hit": 0, "details": []}

    for q in benchmark:
        r = memory.lookup(q["source"], q["datum"])
        expected_hit = q.get("expected_cache_hit", False)
        expected_class = q.get("expected_class", "")

        if r.cache_hit and expected_hit:
            if r.classification == expected_class:
                results["hit_correct_class"] += 1
                outcome = "TP_correct"
            else:
                results["hit_wrong_class"] += 1
                outcome = "TP_wrong_class"
        elif not r.cache_hit and not expected_hit:
            results["miss_expected_miss"] += 1
            outcome = "TN"
        elif r.cache_hit and not expected_hit:
            outcome = "FP"
        else:
            results["miss_expected_hit"] += 1
            outcome = "FN"

        results["details"].append({
            "id": q.get("id"),
            "outcome": outcome,
            "cache_hit": r.cache_hit,
            "similarity": r.similarity_score,
            "classification": r.classification,
            "matched_source": r.matched_cached_source,
            "expected_class": expected_class,
        })

    n = len(benchmark)
    correct = results["hit_correct_class"] + results["miss_expected_miss"]
    results["summary"] = {
        "n": n,
        "correct": correct,
        "accuracy": correct / n if n else 0.0,
        "rule_11_pass": (correct / n if n else 0.0) >= 0.8,
    }
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description="V2.5 Phase B.3.1 — sentence-embedding anchor memory")
    parser.add_argument("--benchmark", type=Path, help="Run retrieval benchmark JSON")
    parser.add_argument("--similarity", type=float, default=DEFAULT_SIMILARITY)
    parser.add_argument("--cache", type=Path, default=DEFAULT_CACHE_PATH)
    args = parser.parse_args()

    if args.benchmark:
        mem = AnchorMemoryV2(cache_path=args.cache, similarity_threshold=args.similarity)
        results = run_benchmark(mem, args.benchmark)
        print(json.dumps(results, indent=2))
        return 0 if results["summary"]["rule_11_pass"] else 1

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
