"""V2.5.1 — LLM-Driven Debate (Production Upgrade for Cluster B).

Replaces pattern-based 12-persona debate (multi_agent_debate.py) with real
LLM calls. Each persona prompts the LLM to generate a genuine alternative
in that persona's style — not template-fitted.

Predicted lift: +2-4% on n=1000 (more nuanced + creative alternatives)
when integrated with V2.6 stack.

Requires ANTHROPIC_API_KEY (or other vendor adapters from tools/v2.5-verifier).

Pattern-based fallback: if no API key, falls back to multi_agent_debate.py
(template generation).
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass
from typing import Any

from .creative import auto_score
from .multi_agent_debate import PERSONAS, DebateResult, generate_alternative

try:
    import anthropic
    _HAS_ANTHROPIC = True
except ImportError:
    _HAS_ANTHROPIC = False


# Persona system prompts for LLM-driven generation
PERSONA_SYSTEM_PROMPTS = {
    "bezos": """You are Jeff Bezos applying the Working-Backwards methodology. Given a problem, write a single-paragraph alternative recommendation that:
1. Starts from the customer press release in 5 years
2. Identifies the single mechanism that produces the press-release outcome
3. Names specific customer outcomes (verifiable metrics)
4. Replaces multi-mechanism approaches with one customer-language-driven design
Use specific, non-buzzword language. Cite Bezos's actual Amazon framework where relevant.""",

    "jobs": """You are Steve Jobs applying the reframe methodology. Given a problem, write a single-paragraph alternative recommendation that:
1. Identifies the obvious feature competitors are improving
2. Kills that feature (replaces with opposite/reverse)
3. Makes the incumbent's strategy obsolete by changing the category
4. Cites specific Apple history (iPhone keyboard, iPod files, iPad multitasking)
Use specific, mechanism-oriented language.""",

    "zhang": """You are Zhang Yiming applying the progression-layer methodology from ByteDance. Given a problem, write a single-paragraph alternative recommendation that:
1. Identifies the short-term metric currently optimized
2. Replaces it with a delayed-satisfaction signal (90-day retention vs minute attention)
3. Creates compounding advantage incumbent cannot reverse
4. Cites specific ByteDance/TikTok/Toutiao history.""",

    "buffett": """You are Warren Buffett applying buy-and-hold capital allocation. Given a problem, write a single-paragraph alternative recommendation that:
1. Identifies the transactional metric being optimized
2. Replaces it with structural durability investment
3. Holds for 30+ years to compound moat
4. Cites Coca-Cola, GEICO, See's Candies as analogs.""",

    "drexler": """You are Mickey Drexler applying perfect-the-basics methodology from Gap/J.Crew. Given a problem, write a single-paragraph alternative recommendation that:
1. Identifies the current breadth (200 SKUs, 100 features)
2. Eliminates 80% to perfect the remaining 20%
3. Becomes known as the place for one specific thing
4. Cites Gap/J.Crew transformation history.""",

    "thiel": """You are Peter Thiel applying find-the-monopoly methodology. Given a problem, write a single-paragraph alternative recommendation that:
1. Identifies the obvious competitive positioning
2. Refuses it — find a market with no direct competitor
3. Define a category where you alone have monopoly power
4. Cite PayPal as currency-bridge, not 'better Western Union'.""",

    "lecun": """You are Yann LeCun applying self-supervised learning methodology. Given a problem, write a single-paragraph alternative recommendation that:
1. Identifies the curated supervised data approach
2. Replaces with self-supervised learning at 100x scale
3. Lets structure emerge from massive unlabeled context
4. Cite foundation models as the proven pattern.""",

    "tegmark": """You are Max Tegmark applying physics-first reasoning. Given a problem, write a single-paragraph alternative recommendation that:
1. Identifies the surface domain features
2. Extracts the underlying physics (entropy, information bounds, energy)
3. Solves at the physics level — predicts incumbent failures
4. Cite cosmology + AI physical reasoning as analogs.""",

    "brunelleschi": """You are Filippo Brunelleschi applying invent-the-engineering-first methodology. Given a problem, write a single-paragraph alternative recommendation that:
1. Identifies the grand structure being attempted
2. Steps back to invent the engineering technique that makes it possible
3. Design discipline precedes brute-force execution
4. Cite Florence Duomo Hoist Gru + double-shell dome (1418-1436).""",

    "borges": """You are Jorge Luis Borges applying catalog-the-universe methodology. Given a problem, write a single-paragraph alternative recommendation that:
1. Identifies the generation-focused approach (create new content)
2. Replaces with cataloging the underlying patterns
3. The library organizes the universe; navigation produces value
4. Cite Library of Babel (1941) + Aleph + Garden of Forking Paths.""",

    "cucinelli": """You are Brunello Cucinelli applying humanistic capitalism methodology. Given a problem, write a single-paragraph alternative recommendation that:
1. Identifies optimization-via-outsourcing approach
2. Preserves craft + shares profit 50/50 with workers
3. Heritage becomes brand moat unreachable by efficiency-first competitors
4. Cite Solomeo manufacturing model (50% profit share, restored medieval village).""",

    "hermes": """You are Hermès leadership applying limited-supply + family-heritage methodology. Given a problem, write a single-paragraph alternative recommendation that:
1. Identifies the scaling/efficiency optimization
2. Limits production deliberately to preserve craft + brand
3. Family ownership over centuries enables values incompatible with shareholder pressure
4. Cite Birkin waitlists, 6th-generation Dumas-Hermès family ownership.""",
}


@dataclass
class LLMDebateResult:
    original_recommendation: str
    original_score: int
    alternatives: list[dict[str, Any]]
    winner: str
    winning_text: str
    winning_score: int
    score_lift: int
    used_llm: bool
    total_api_cost_usd: float

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def llm_generate_alternative(
    persona_name: str,
    original_recommendation: str,
    client: Any,
    model: str = "claude-opus-4-8",
    max_tokens: int = 512,
) -> tuple[str, int, int]:
    """Use Anthropic API to generate a persona-style alternative.

    Returns: (alternative_text, tokens_in, tokens_out)
    """
    system_prompt = PERSONA_SYSTEM_PROMPTS.get(persona_name, "")
    user_prompt = f"Original recommendation: {original_recommendation}\n\nGenerate your alternative as a single dense paragraph (3-5 sentences)."

    response = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        temperature=0.7,
        system=system_prompt,
        messages=[{"role": "user", "content": user_prompt}],
    )
    text = response.content[0].text if response.content else ""
    return text, response.usage.input_tokens, response.usage.output_tokens


def run_llm_debate(
    original_recommendation: str,
    margin: int = 1,
    model: str = "claude-opus-4-8",
    fallback_on_no_api: bool = True,
) -> LLMDebateResult:
    """Run debate among 12 personas using real LLM calls.

    If ANTHROPIC_API_KEY not configured, falls back to pattern-based debate
    from multi_agent_debate.py.
    """
    client = None
    if _HAS_ANTHROPIC and os.environ.get("ANTHROPIC_API_KEY"):
        client = anthropic.Anthropic()

    used_llm = client is not None
    total_cost = 0.0
    original_score = auto_score(original_recommendation).total

    alternatives = []
    for persona in PERSONAS:
        if used_llm:
            try:
                text, tok_in, tok_out = llm_generate_alternative(
                    persona["name"], original_recommendation, client, model=model
                )
                cost = (tok_in * 15 + tok_out * 75) / 1_000_000
                total_cost += cost
            except Exception:
                text = generate_alternative(persona, original_recommendation)
        else:
            if not fallback_on_no_api:
                raise RuntimeError("ANTHROPIC_API_KEY not configured")
            text = generate_alternative(persona, original_recommendation)

        score = auto_score(text).total
        alternatives.append({
            "persona": persona["name"],
            "alternative": text,
            "score": score,
            "lift_over_original": score - original_score,
        })

    best_alt = max(alternatives, key=lambda a: a["score"])
    if best_alt["score"] >= original_score + margin:
        winner = best_alt["persona"]
        winning_text = best_alt["alternative"]
        winning_score = best_alt["score"]
        score_lift = winning_score - original_score
    else:
        winner = "original"
        winning_text = original_recommendation
        winning_score = original_score
        score_lift = 0

    return LLMDebateResult(
        original_recommendation=original_recommendation,
        original_score=original_score,
        alternatives=alternatives,
        winner=winner,
        winning_text=winning_text,
        winning_score=winning_score,
        score_lift=score_lift,
        used_llm=used_llm,
        total_api_cost_usd=total_cost,
    )


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(description="V2.5.1 LLM-driven debate")
    parser.add_argument("recommendation", help="V2.5 recommendation to debate")
    parser.add_argument("--margin", type=int, default=1)
    parser.add_argument("--model", default="claude-opus-4-8")
    parser.add_argument("--no-fallback", action="store_true", help="Fail if no API key")
    args = parser.parse_args()

    result = run_llm_debate(
        args.recommendation,
        margin=args.margin,
        model=args.model,
        fallback_on_no_api=not args.no_fallback,
    )
    print(json.dumps(result.as_dict(), indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
