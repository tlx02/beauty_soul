"""B.2 inline numeric verifier (V2.15.1).

V2.15's Rule 13 fixed conditional-probability refusal discipline (39%->0%) at
the PROMPT layer, but compound-growth / CAGR errors only dropped 25.9%->22.2%:
the model is *told* to use the geometric formula but still arithmetic-averages.
Prompt instruction has a ceiling — the only fix is to actually compute.

B.2 inline closes it: pull every "<expression> = <claimed_number>" pair the
model wrote in its show-work (Rule 13a mandates show-work, which makes the
expressions extractable), evaluate the expression with safe_eval, and flag any
claim whose stated result disagrees with the computed one beyond tolerance.
On a real arithmetic error, the caller applies Rule 9 and caps confidence LOW.

This is deterministic arithmetic (safe_eval, 20/20 calibrated) — no LLM call,
no extra cost. Rule 12 binary-marker audit does NOT apply (it's a numeric
comparison, not a keyword detector).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .numeric import safe_eval

# "<expr> = <number>"  — expr must contain an operator so we skip "x = 5" defs.
# number may carry %, currency, thousands separators, surrounding ** bold, etc.
# Match a FULL "<expr> = <number>" where the expr starts at a clean boundary
# (not preceded by a digit/operator — avoids grabbing the right operand of an
# earlier "200 × (...)" as a fresh lhs) and the rhs number is terminal (followed
# by end / whitespace / punctuation, not another operator that would make it a
# mid-chain step like "= 20 + 60").
_EQ = re.compile(
    r"(?:(?<=[:：（(\[【])|(?<=\s)|^)"                                   # lhs left-boundary
    r"(?<![-+*/×xX0-9.]\s)(?<![-+*/×xX0-9.])"                            # ...but NOT right after an operator/operand (mid-chain)
    r"([0-9(][0-9eE.,\s*/+\-^×xX()%]*?[*/+\-^×xX%)][0-9eE.,\s*/+\-^×xX()%]*?)"   # lhs w/ an operator
    r"\s*[=≈]\s*"
    r"[*$￥€£]?\s*(-?[0-9][0-9,]*\.?[0-9]*)\s*([%]?)"
    r"(?![0-9.,]*\s*[*/+\-^×xX])",                                       # rhs not followed by another operator
    re.MULTILINE,
)

# expressions we cannot evaluate (variables, prose) get skipped, not flagged.
_TOL = 0.01  # 1% relative tolerance, matches B.2 calibration


@dataclass
class NumericCheck:
    expr: str
    claimed: float
    computed: float
    ok: bool


@dataclass
class B2Result:
    checks: list = field(default_factory=list)
    n_checked: int = 0
    n_error: int = 0

    @property
    def any_error(self) -> bool:
        return self.n_error > 0


def _normalize(expr: str) -> str:
    e = expr.strip().rstrip(".")
    e = e.replace("×", "*").replace("x", "*").replace("X", "*").replace("^", "**")
    e = e.replace(",", "").replace(" ", "").replace("%", "/100")
    return e


def _delatex(text: str) -> str:
    """Normalize LaTeX math operators/delimiters to plain ASCII so the matcher
    sees a uniform syntax (real answers wrap arithmetic in \\[ ... \\times ... \\])."""
    t = text
    for a, b in (("\\times", "*"), ("\\cdot", "*"), ("\\div", "/"),
                 ("\\left", ""), ("\\right", ""), ("\\%", "%"),
                 ("\\[", " "), ("\\]", " "), ("\\(", " "), ("\\)", " "),
                 ("$$", " "), ("$", " "), ("\\,", ""), ("\\;", "")):
        t = t.replace(a, b)
    return t


# V2.19 (exp/72): CHECK-line fast path. The free-form extractor above is
# deliberately conservative (zero false positives >> recall) and caught 0/4 real
# multi-step arithmetic errors in exp/72 D3 — models write 万-units, mid-chain
# steps and roots it must skip. Rule 13 now MANDATES terminal lines in the strict
# form "CHECK: <pure-ascii expr> = <number>", which this parser verifies with
# none of the boundary ambiguity. Same zero-FP guarantee (the format is exact),
# full recall on the values that matter (the model is told to emit one per key
# computed value).
_CHECK_LINE = re.compile(
    r"^\s*CHECK[:：]\s*([0-9eE.()\s*/+\-]+?)\s*=\s*(-?[0-9][0-9,]*\.?[0-9]*)\s*$",
    re.MULTILINE,
)


def run_b2_check_lines(recommendation: str, tolerance: float = _TOL) -> B2Result:
    """Verify the mandated 'CHECK: <expr> = <number>' terminal lines."""
    res = B2Result()
    for m in _CHECK_LINE.finditer(recommendation):
        expr = m.group(1).replace(" ", "").replace(",", "")
        if not re.search(r"[*/+\-]|\*\*", expr):
            continue
        computed = safe_eval(expr)
        if computed is None:
            continue
        try:
            claimed = float(m.group(2).replace(",", ""))
        except ValueError:
            continue
        denom = max(abs(claimed), abs(computed), 1e-9)
        ok = abs(claimed - computed) / denom <= tolerance
        res.checks.append(NumericCheck(expr=m.group(1).strip(), claimed=claimed, computed=computed, ok=ok))
        res.n_checked += 1
        if not ok:
            res.n_error += 1
    return res


def build_b2_correction(b2: B2Result) -> str:
    """One corrective instruction for a single recompute retry (V2.19 loop)."""
    lines = [
        f"- 你写的 {c.expr} 实际等于 {round(c.computed, 6)},但你声称 {c.claimed}"
        for c in b2.checks if not c.ok
    ]
    return (
        "你上一次回答里的算术有错(计算器逐条核对):\n" + "\n".join(lines) +
        "\n请以正确的计算结果为准,重新给出完整回答(保持同样的格式要求,"
        "结尾仍须有 CHECK 行)。不要解释上次为何算错,直接给修正后的回答。"
    )


def run_b2_inline(recommendation: str, max_checks: int = 12, tolerance: float = _TOL) -> B2Result:
    """Extract '<expr> = <number>' pairs from show-work, verify each with safe_eval.

    DESIGN PRIORITY: zero false positives >> high recall. Flagging a CORRECT
    answer as LOW destroys trust; missing a wrong one only forfeits a catch the
    prompt-layer Rule 13 already mostly handles. So we deliberately SKIP any
    pattern whose boundary/percent semantics are ambiguous, even at the cost of
    recall. Percent expressions (lhs containing %) are skipped entirely — the
    "5% - 2% = 3%" vs "0.05 - 0.02 = 0.03" scaling is irreducibly ambiguous from
    text alone, and that ambiguity caused every observed false positive.
    """
    res = B2Result()
    seen_spans = []
    recommendation = _delatex(recommendation)
    for m in _EQ.finditer(recommendation):
        if res.n_checked >= max_checks:
            break
        raw_expr, raw_num, pct = m.group(1), m.group(2), m.group(3)
        # Skip if this lhs overlaps a previous match's span (nested mis-grab).
        start = m.start(1)
        if any(s <= start < e for s, e in seen_spans):
            continue
        # Skip percent-bearing expressions entirely (ambiguous scaling).
        if "%" in raw_expr or pct == "%":
            continue
        expr = _normalize(raw_expr)
        # need at least one real binary operator after normalization
        if not re.search(r"[*/+\-]|\*\*", expr):
            continue
        computed = safe_eval(expr)
        if computed is None:
            continue
        seen_spans.append((m.start(1), m.end(2)))
        try:
            claimed = float(raw_num.replace(",", ""))
        except ValueError:
            continue
        denom = max(abs(claimed), abs(computed), 1e-9)
        ok = abs(claimed - computed) / denom <= tolerance
        res.checks.append(NumericCheck(expr=raw_expr.strip(), claimed=claimed, computed=computed, ok=ok))
        res.n_checked += 1
        if not ok:
            res.n_error += 1
    return res
