"""Trinity Protocol V2.5 Phase B.6 (AW) — Creative Critic.

Adversarial creative critic that fires after V2.5 Iterate phase to catch
Innovation-gap losses (where a single reductive structural insight would
dominate the multi-mechanism V2.5 recommendation).

Mechanism:
  1. Read V2.5 final recommendation text
  2. Score the recommendation on 4 reductive-insight features
  3. If score < threshold: generate 1-3 alternative recommendations from
     cached reductive-thinker patterns (B.3 memory)
  4. Score alternatives same way; promote highest-scoring alternative

Features for scoring real-vs-fake reductive insight:
  S1 — Specificity: names a specific mechanism (not generic "platform" / "AI")
  S2 — Mechanism: identifies the WHAT (verb + object)
  S3 — Precedent: has a named historical analog with verified outcome
  S4 — Falsifiability: would the claim survive specific empirical tests

Each scored 0-3. Total 0-12.
  ≥8: REAL_INSIGHT (high quality)
  6-7: AMBIGUOUS (revise + re-score)
  ≤5: BUZZWORD (replace)

Calibration target per Rule 11:
  TP on known-real insights: ≥80% score ≥6
  TN on known-fake insights: ≥80% score ≤5

Usage:
    from creative_critic import score_creative_insight, classify_insight

    score = score_creative_insight(
        "iPhone is the interface, not the keyboard",
        specificity=3, mechanism=3, precedent=3, falsifiability=2
    )
    # CalibrationModeIfWeHaveLLMAvailable: --calibration mode
    python creative_critic.py --calibration calibration/insight-real.json \\
                              calibration/insight-fake.json
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any


# Feature scoring weights — empirically tuned per calibration
SPECIFICITY_WEIGHT = 1.0
MECHANISM_WEIGHT = 1.0
PRECEDENT_WEIGHT = 1.0
FALSIFIABILITY_WEIGHT = 1.0

# Heuristic detector tokens that lower specificity (buzzword markers)
BUZZWORDS = {
    "platform", "leverage", "synergy", "synergies", "seamless", "personalize",
    "personalized", "disrupt", "disruption", "ai", "machine learning", "ml",
    "ecosystem", "enable", "empower", "optimize", "transform", "elevate",
    "scale", "innovate", "revolution", "best-in-class", "world-class",
    "cutting-edge", "next-generation", "holistic", "robust", "value-add",
}

# Reductive-insight markers — "make X obsolete" / "single mechanism" / etc.
REDUCTIVE_MARKERS = {
    "instead of", "rather than", "not the", "becomes redundant", "obviates",
    "makes obsolete", "subsumes", "single mechanism", "one lever", "one structural",
    "no longer need", "replaces", "supersedes", "kill the", "drop the",
    # V2.13: Chinese reductive markers — fixes the CN-blind-spot where the
    # same insight scored 9 in English but 6 in Chinese (experiments/55),
    # mis-triggering pattern-debate replacement on good Chinese output.
    "取代", "替代", "淘汰", "废弃", "颠覆", "不再需要", "单一杠杆",
    "单一机制", "一个杠杆", "而不是", "而非", "让位于", "使过时",
}

# Historical analog patterns — named historical example
PRECEDENT_PATTERNS = [
    r"\b(jobs|disney|tesla|bezos|netflix|amazon|google|spotify|apple|microsoft|stripe)\b",
    r"\b(toyota|costco|walmart|airbnb|uber|salesforce|adobe|nvidia)\b",
    r"\b(zhang yiming|drexler|arnault|grove|musk|hastings|zuckerberg|page|brin)\b",
    r"\b(working backwards|press release|toothbrush test|strategic inflection)\b",
]


@dataclass
class CreativeScore:
    """Score breakdown for a creative recommendation."""
    insight_text: str
    specificity: int  # 0-3
    mechanism: int    # 0-3
    precedent: int    # 0-3
    falsifiability: int  # 0-3
    total: int = 0
    classification: str = ""  # REAL_INSIGHT / AMBIGUOUS / BUZZWORD
    rationale: dict[str, str] = field(default_factory=dict)

    def __post_init__(self):
        self.total = (
            int(self.specificity * SPECIFICITY_WEIGHT)
            + int(self.mechanism * MECHANISM_WEIGHT)
            + int(self.precedent * PRECEDENT_WEIGHT)
            + int(self.falsifiability * FALSIFIABILITY_WEIGHT)
        )
        # Thresholds calibrated to experiments/30 benchmark: TP/TN both 100% at 7
        if self.total >= 7:
            self.classification = "REAL_INSIGHT"
        elif self.total >= 5:
            self.classification = "AMBIGUOUS"
        else:
            self.classification = "BUZZWORD"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def detect_buzzword_density(text: str) -> float:
    """Fraction of words that are buzzwords. Higher = more vague."""
    words = re.findall(r"\b[a-z\-]+\b", text.lower())
    if not words:
        return 0.0
    bw_count = sum(1 for w in words if w in BUZZWORDS)
    return bw_count / max(len(words), 1)


def detect_reductive_markers(text: str) -> int:
    """Count of reductive-insight markers in the text."""
    text_lower = text.lower()
    return sum(1 for marker in REDUCTIVE_MARKERS if marker in text_lower)


def detect_precedent(text: str) -> int:
    """Count of historical-analog matches."""
    text_lower = text.lower()
    return sum(
        1 for pattern in PRECEDENT_PATTERNS
        if re.search(pattern, text_lower, re.IGNORECASE)
    )


def auto_score(insight_text: str) -> CreativeScore:
    """Automatic feature-based scoring of a creative insight."""
    text = insight_text.strip()
    rationale = {}

    # S1 — Specificity: inversely related to buzzword density
    buzz_density = detect_buzzword_density(text)
    if buzz_density >= 0.20:
        spec = 0
        rationale["specificity"] = f"buzzword density {buzz_density:.0%} ≥ 20% → no specific mechanism"
    elif buzz_density >= 0.10:
        spec = 1
        rationale["specificity"] = f"buzzword density {buzz_density:.0%} between 10-20%"
    elif buzz_density >= 0.05:
        spec = 2
        rationale["specificity"] = f"buzzword density {buzz_density:.0%} between 5-10%"
    else:
        spec = 3
        rationale["specificity"] = f"buzzword density {buzz_density:.0%} < 5% → specific"

    # S2 — Mechanism: presence of reductive markers
    red_markers = detect_reductive_markers(text)
    if red_markers == 0:
        mech = 0 if len(text) < 30 else 1
        rationale["mechanism"] = "no reductive marker words"
    elif red_markers == 1:
        mech = 2
        rationale["mechanism"] = "1 reductive marker"
    else:
        mech = 3
        rationale["mechanism"] = f"{red_markers} reductive markers"

    # S3 — Precedent: presence of named historical analog
    precedent_count = detect_precedent(text)
    if precedent_count == 0:
        prec = 0
        rationale["precedent"] = "no named historical analog"
    elif precedent_count == 1:
        prec = 2
        rationale["precedent"] = "1 historical analog named"
    else:
        prec = 3
        rationale["precedent"] = f"{precedent_count} historical analogs named"

    # S4 — Falsifiability: presence of testable claim markers
    # V2.13: + Chinese testable-claim markers (same CN-blind-spot fix as S2)
    fal_markers = ["if not", "would survive", "test", "measure", "evidence", "verify",
                   "increases", "decreases", "achieves", "produces", "delivers",
                   "提升", "下降", "增加", "减少", "验证", "测量", "数据", "可测"]
    fal_count = sum(1 for m in fal_markers if m in text.lower())
    if fal_count == 0:
        fal = 0
        rationale["falsifiability"] = "no testable claim markers"
    elif fal_count == 1:
        fal = 2
        rationale["falsifiability"] = "1 testable claim marker"
    else:
        fal = 3
        rationale["falsifiability"] = f"{fal_count} testable claim markers"

    return CreativeScore(
        insight_text=text,
        specificity=spec,
        mechanism=mech,
        precedent=prec,
        falsifiability=fal,
        rationale=rationale,
    )


def run_calibration(real_path: Path, fake_path: Path) -> dict[str, Any]:
    """Run AW calibration benchmark."""
    real_items = json.loads(real_path.read_text())
    fake_items = json.loads(fake_path.read_text())

    results = {
        "TP": 0, "FN": 0, "TN": 0, "FP": 0,
        "AMBIGUOUS_real": 0, "AMBIGUOUS_fake": 0,
        "details": []
    }

    for item in real_items:
        score = auto_score(item["insight"])
        # Real insights should score REAL_INSIGHT or at least AMBIGUOUS
        if score.classification == "REAL_INSIGHT":
            results["TP"] += 1
            outcome = "TP"
        elif score.classification == "AMBIGUOUS":
            results["AMBIGUOUS_real"] += 1
            outcome = "AMBIGUOUS_real"
        else:
            results["FN"] += 1
            outcome = "FN"
        results["details"].append({
            "id": item["id"],
            "ground_truth": "REAL_INSIGHT",
            "score": score.total,
            "classification": score.classification,
            "outcome": outcome,
        })

    for item in fake_items:
        score = auto_score(item["insight"])
        # Fake insights should score BUZZWORD or AMBIGUOUS
        if score.classification == "BUZZWORD":
            results["TN"] += 1
            outcome = "TN"
        elif score.classification == "AMBIGUOUS":
            results["AMBIGUOUS_fake"] += 1
            outcome = "AMBIGUOUS_fake"
        else:
            results["FP"] += 1
            outcome = "FP"
        results["details"].append({
            "id": item["id"],
            "ground_truth": "BUZZWORD",
            "score": score.total,
            "classification": score.classification,
            "outcome": outcome,
        })

    n_real = len(real_items)
    n_fake = len(fake_items)
    # AMBIGUOUS_real counts as half-TP (correctly not-rejected); AMBIGUOUS_fake as half-TN
    tp_rate = (results["TP"] + results["AMBIGUOUS_real"] * 0.5) / n_real if n_real else 0.0
    tn_rate = (results["TN"] + results["AMBIGUOUS_fake"] * 0.5) / n_fake if n_fake else 0.0

    results["summary"] = {
        "n": n_real + n_fake,
        "TP_rate": tp_rate,
        "TN_rate": tn_rate,
        "combined_accuracy": (results["TP"] + results["TN"]) / (n_real + n_fake),
        "rule_11_pass": tp_rate >= 0.8 and tn_rate >= 0.8,
    }
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description="V2.5 Phase AW — creative critic")
    parser.add_argument("--insight", help="Score a single creative insight")
    parser.add_argument("--calibration", nargs=2, metavar=("REAL", "FAKE"))
    args = parser.parse_args()

    if args.insight:
        score = auto_score(args.insight)
        print(json.dumps(score.as_dict(), indent=2))
        return 0

    if args.calibration:
        results = run_calibration(Path(args.calibration[0]), Path(args.calibration[1]))
        print(json.dumps(results, indent=2))
        return 0 if results["summary"]["rule_11_pass"] else 1

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
