"""V2.5.1 — Sentence-Embedding Cache Matcher.

Upgrades V2.6 v26_integration.find_relevant_anchors() from keyword matching
to cosine similarity via sentence-transformers.

Predicted lift: +1-2% on n=1000 (more precise cache hits, fewer false negatives)
when integrated with full V2.6 stack. Combined with V2.5.1 LLM-driven debate
(llm_debate.py) and Cluster C live web, pushes V2.6 from 96.7% toward 97-98%
NFL ceiling.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    from sentence_transformers import SentenceTransformer
    import numpy as np
    _HAS_SBERT = True
except ImportError:
    _HAS_SBERT = False


DEFAULT_MODEL = "all-MiniLM-L6-v2"
DEFAULT_SIMILARITY = 0.50


@dataclass
class AnchorMatch:
    source: str
    datum: str
    classification: str
    subdomain_or_culture: str
    similarity: float


class EmbeddingCacheMatcher:
    """Semantic similarity cache matcher for V2.6 Cluster A and D caches."""

    def __init__(
        self,
        cache_paths: list[Path],
        similarity_threshold: float = DEFAULT_SIMILARITY,
        model_name: str = DEFAULT_MODEL,
    ):
        if not _HAS_SBERT:
            raise ImportError("Requires sentence-transformers. Install: pip install sentence-transformers")
        self.similarity_threshold = similarity_threshold
        self.model = SentenceTransformer(model_name)
        self.anchors: list[dict[str, Any]] = []
        self.embeddings = None

        for path in cache_paths:
            self._load(path)

        # Compute embeddings for all anchors once
        if self.anchors:
            texts = [
                f"{a.get('source', '')} | {a.get('datum', '')} | {a.get('subdomain', a.get('culture', ''))}"
                for a in self.anchors
            ]
            self.embeddings = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=False)

    def _load(self, cache_path: Path) -> None:
        try:
            data = json.loads(cache_path.read_text())
            self.anchors.extend(data.get("anchors", []))
        except (json.JSONDecodeError, FileNotFoundError):
            pass

    def find_relevant(
        self,
        query_text: str,
        max_results: int = 5,
    ) -> list[AnchorMatch]:
        """Cosine-similarity lookup for anchors relevant to query_text."""
        if not self.anchors or self.embeddings is None:
            return []

        query_emb = self.model.encode([query_text], convert_to_numpy=True, show_progress_bar=False)[0]

        # Cosine similarities
        norms = np.linalg.norm(self.embeddings, axis=1) * np.linalg.norm(query_emb)
        dots = self.embeddings @ query_emb
        cosines = dots / (norms + 1e-10)

        # Get top-k matches above threshold
        indices = np.argsort(cosines)[::-1][:max_results * 2]
        matches = []
        for idx in indices:
            idx = int(idx)
            sim = float(cosines[idx])
            if sim < self.similarity_threshold:
                break
            anchor = self.anchors[idx]
            matches.append(AnchorMatch(
                source=anchor.get("source", ""),
                datum=anchor.get("datum", ""),
                classification=anchor.get("classification", "PLAUSIBLE"),
                subdomain_or_culture=anchor.get("subdomain", anchor.get("culture", "")),
                similarity=sim,
            ))
            if len(matches) >= max_results:
                break

        return matches


def load_v26_combined_matcher() -> EmbeddingCacheMatcher:
    """Load all V2.6 caches (expanded Cluster A + D) into one matcher."""
    cache_dir = Path(__file__).parent / "calibration"
    cache_paths = [
        cache_dir / "practitioner-cache-v26.json",
        cache_dir / "practitioner-cache-v26-expanded.json",
        cache_dir / "cultural-practitioner-cache-v26.json",
        cache_dir / "cultural-practitioner-cache-v26-expanded.json",
    ]
    return EmbeddingCacheMatcher(cache_paths=cache_paths)


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(description="V2.5.1 embedding cache matcher")
    parser.add_argument("query", help="Query text to match against V2.6 caches")
    parser.add_argument("--similarity", type=float, default=DEFAULT_SIMILARITY)
    parser.add_argument("--max-results", type=int, default=5)
    args = parser.parse_args()

    matcher = load_v26_combined_matcher()
    matcher.similarity_threshold = args.similarity
    matches = matcher.find_relevant(args.query, max_results=args.max_results)
    output = [
        {
            "source": m.source,
            "subdomain_or_culture": m.subdomain_or_culture,
            "similarity": m.similarity,
            "classification": m.classification,
        }
        for m in matches
    ]
    print(json.dumps(output, indent=2))
    return 0 if matches else 1


if __name__ == "__main__":
    sys.exit(main())
