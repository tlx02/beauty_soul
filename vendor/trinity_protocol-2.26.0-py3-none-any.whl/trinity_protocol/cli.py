"""Trinity Protocol V2.5+AW — Command Line Interface.

Usage:
    trinity-verify --help
    trinity-verify numeric "$50M / 5 years = $10M annual"
    trinity-verify probability --method binomial_at_or_above --n 100 --p 0.5 --k 60
    trinity-verify creative "iPhone replaces the keyboard with the screen itself"
    trinity-verify prompt  # prints the canonical V2.4.4a prompt
    trinity-verify calibrate  # runs all calibration benchmarks
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import (
    SYSTEM_PROMPT,
    verify_numeric,
    verify_probability,
    score_creative,
    __version__,
)


def cmd_numeric(args) -> int:
    """Verify a numeric claim."""
    # In offline-CLI mode, prompt user for parsed values since we don't auto-parse
    print(f"Claim: {args.claim}", file=sys.stderr)
    print("Note: full LLM extraction requires --api-key; using offline mode")
    print("Provide claimed value + math expression separately:")
    if not args.claimed:
        print("Use --claimed <number> --math '<python expr>' for offline verification")
        return 1
    # Offline path: directly use safe_eval through verify_numeric internal
    from .numeric import safe_eval

    computed = safe_eval(args.math)
    if computed is None:
        result = {"classification": "UNPARSEABLE", "computed": None}
    else:
        delta = abs(args.claimed - computed) / max(abs(args.claimed), abs(computed), 0.001)
        if delta < 0.01:
            cls = "VERIFIED"
        elif delta < 0.02:
            cls = "PARTIAL_VERIFIED"
        else:
            cls = "ERROR"
        result = {
            "classification": cls,
            "claimed": args.claimed,
            "computed": computed,
            "delta_ratio": delta,
        }
    print(json.dumps(result, indent=2))
    return 0 if result["classification"] in ("VERIFIED", "PARTIAL_VERIFIED") else 1


def cmd_probability(args) -> int:
    """Verify a probability/statistical claim."""
    params = {}
    if args.n is not None:
        params["n"] = args.n
    if args.p is not None:
        params["p"] = args.p
    if args.k is not None:
        params["k"] = args.k
    if args.p1 is not None:
        params["p1"] = args.p1
    if args.p2 is not None:
        params["p2"] = args.p2

    verdict = verify_probability(
        claim_text=args.claim or "(no claim text)",
        claimed_value=args.claimed,
        method=args.method,
        params=params,
        tolerance=args.tolerance,
    )
    print(json.dumps(verdict.as_dict(), indent=2))
    return 0 if verdict.classification in ("VERIFIED", "PARTIAL_VERIFIED") else 1


def cmd_creative(args) -> int:
    """Score a creative insight."""
    score = score_creative(args.insight)
    print(json.dumps(score.as_dict(), indent=2))
    return 0 if score.classification == "REAL_INSIGHT" else 1


def cmd_prompt(args) -> int:
    """Print the canonical V2.4.4a system prompt."""
    print(SYSTEM_PROMPT)
    return 0


def cmd_solve(args) -> int:
    """One-shot Trinity Protocol solver — V2.8 alpha default."""
    from . import solve as solve_fn
    # --ttc flag overrides --version to v28-beta
    version = "v28-beta" if args.ttc else args.version
    try:
        common_kwargs = dict(
            domain=args.domain, model=args.model,
            backend=args.backend, max_tokens=args.max_tokens,
            verbose=args.verbose,
            version=version,
            ttc=args.ttc,
            ttc_max_n=args.ttc_max_n,
            verify_anchors=args.verify_anchors,
            file_paths=args.file_paths,
            grep_query=args.grep_query,
            git_log=args.git_log,
            cross_vendor_skeptic=args.cross_vendor_skeptic,
            verify_consistency=args.verify_consistency,
            adaptive=not args.no_adaptive,
        )
        if args.json:
            result = solve_fn(args.problem, return_dict=True, **common_kwargs)
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            text = solve_fn(args.problem, **common_kwargs)
            print(text)
        return 0
    except (RuntimeError, ImportError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_calibrate(args) -> int:
    """Run all calibration benchmarks offline."""
    from .numeric import safe_eval
    from .formal import verify_probability_claim, run_calibration as run_prob_cal
    from .creative import run_calibration as run_cc_cal

    calibration_dir = Path(__file__).parent / "calibration"
    results = {}

    # B.2 numeric calibration (just safe_eval)
    print("Running B.2 numeric calibration...", file=sys.stderr)
    correct = json.loads((calibration_dir / "numeric-known-correct.json").read_text())
    correct_pass = sum(
        1 for c in correct
        if safe_eval(c["math_to_verify"].split("=")[0].strip()) is not None
    )
    results["B.2"] = {"correct_pass": correct_pass, "of": len(correct)}

    # B.4 probability calibration
    print("Running B.4 probability calibration...", file=sys.stderr)
    prob_results = run_prob_cal(
        calibration_dir / "probability-known-correct.json",
        calibration_dir / "probability-known-incorrect.json",
    )
    results["B.4"] = prob_results["summary"]

    # AW creative critic calibration
    print("Running AW creative critic calibration...", file=sys.stderr)
    cc_results = run_cc_cal(
        calibration_dir / "insight-real.json",
        calibration_dir / "insight-fake.json",
    )
    results["AW"] = cc_results["summary"]

    print(json.dumps(results, indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="trinity-verify",
        description=f"Trinity Protocol V2.5+AW v{__version__} — verification CLI",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    subparsers = parser.add_subparsers(dest="command", help="Subcommands")

    # numeric
    p_num = subparsers.add_parser("numeric", help="Verify a numeric / arithmetic claim")
    p_num.add_argument("claim", help="Claim text")
    p_num.add_argument("--claimed", type=float, help="Claimed numeric value")
    p_num.add_argument("--math", help="Python math expression to verify against")
    p_num.set_defaults(func=cmd_numeric)

    # probability
    p_prob = subparsers.add_parser("probability", help="Verify a probability/statistical claim")
    p_prob.add_argument("--claim", help="Claim text")
    p_prob.add_argument("--claimed", type=float, required=True, help="Claimed probability value")
    p_prob.add_argument("--method", required=True,
                        choices=["binomial_at_or_above", "binomial_at_or_below",
                                 "binomial_pmf", "independent_and",
                                 "normal_ci_upper", "normal_ci_lower", "expected_value_dice"])
    p_prob.add_argument("--n", type=int)
    p_prob.add_argument("--p", type=float)
    p_prob.add_argument("--k", type=int)
    p_prob.add_argument("--p1", type=float)
    p_prob.add_argument("--p2", type=float)
    p_prob.add_argument("--tolerance", type=float, default=0.01)
    p_prob.set_defaults(func=cmd_probability)

    # creative
    p_cre = subparsers.add_parser("creative", help="Score a creative insight (AW)")
    p_cre.add_argument("insight", help="Creative insight text")
    p_cre.set_defaults(func=cmd_creative)

    # prompt
    p_p = subparsers.add_parser("prompt", help="Print canonical V2.4.4a system prompt")
    p_p.set_defaults(func=cmd_prompt)

    # calibrate
    p_cal = subparsers.add_parser("calibrate", help="Run all calibration benchmarks")
    p_cal.set_defaults(func=cmd_calibrate)

    # solve — the one-shot Trinity Protocol solver (V2.8 alpha default)
    p_solve = subparsers.add_parser("solve",
        help="One-shot solver — V2.8 alpha default (98.0% / -4% tokens / -3% latency)")
    p_solve.add_argument("problem", help="Problem/question (quote if has spaces)")
    p_solve.add_argument("--domain", default="",
                         help="Domain hint (e.g., 'Italian luxury', 'rare oncology')")
    p_solve.add_argument("--version", default="v224",
                         choices=["v26", "v27", "v28-alpha", "v28-beta", "v211", "v212",
                                  "v213", "v214", "v215", "v216", "v217", "v218", "v219",
                                  "v220", "v221", "v222", "v223", "v224"],
                         help="Framework version: v224=default(adaptive dispatch + rule "
                              "potency + recompute loop + code precision + composition + "
                              "pressure check + exp/76 false-premise check) / v216=full "
                              "14-rule always-on / v26-v223=legacy")
    p_solve.add_argument("--no-adaptive", action="store_true",
                         help="Disable LLM dispatch; run the full framework on every question")
    p_solve.add_argument("--ttc", action="store_true",
                         help="Enable V2.8 beta TTC scaling (overrides --version)")
    p_solve.add_argument("--ttc-max-n", type=int, default=10,
                         help="TTC hard cap rounds (default 10)")
    p_solve.add_argument("--backend", default="auto",
                         choices=["auto", "anthropic", "openrouter"],
                         help="Backend: auto / anthropic (Claude) / openrouter (DeepSeek)")
    p_solve.add_argument("--model", default=None,
                         help="Model override (e.g., deepseek/deepseek-chat / claude-opus-4-8)")
    p_solve.add_argument("--max-tokens", type=int, default=4096)
    p_solve.add_argument("--verify-anchors", action="store_true",
                         help="V2.10: B.1 inline anchor verifier (Rule 9 enforce, +~\\$0.005)")
    p_solve.add_argument("--file-paths", nargs="+", default=None, dest="file_paths",
                         metavar="GLOB",
                         help="V2.11: read these files (globs) into context (codebase-aware)")
    p_solve.add_argument("--grep-query", default=None, dest="grep_query",
                         help="V2.11: grep the repo for this query and inject matches")
    p_solve.add_argument("--git-log", action="store_true", dest="git_log",
                         help="V2.11: inject last 20 commits into context")
    p_solve.add_argument("--cross-vendor-skeptic", action="store_true", dest="cross_vendor_skeptic",
                         help="V2.11/12: B.1 skeptic + B.5 judge use a different vendor (3-vote)")
    p_solve.add_argument("--verify-consistency", dest="verify_consistency",
                         action="store_true", default=None,
                         help="V2.12: force B.5 codebase-consistency verifier "
                              "(default: auto when codebase context present)")
    p_solve.add_argument("--no-verify-consistency", dest="verify_consistency",
                         action="store_false",
                         help="V2.12: disable B.5 even when codebase context is present")
    p_solve.add_argument("--verbose", "-v", action="store_true", help="Show metadata")
    p_solve.add_argument("--json", action="store_true", help="Output JSON instead of just text")
    p_solve.set_defaults(func=cmd_solve)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return 1
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
