"""V2.17/V2.18 Adaptive activation.

V2.18 (exp/71): same triage architecture as V2.17; what changed is rule POTENCY
and triage PRECISION, both from per-item failure evidence (exp/71 diagnosis):
  - _R_PSEUDO mandates answer structure (root cause leads, surface ask demoted
    to one closing paragraph) — V2.17 fired correctly but still lost 8/16.
  - _R_STRATEGY mandates a first-line KEEP/REMOVE verdict, no hedge padding.
  - _R_NUMERIC adds overlapping-sets containment trap + break-even ceil.
  - _LLM_CLS_SYS gets numeric/strategy counter-examples (asymmetric: miss-averse
    for pseudo, false-positive-averse for numeric/strategy).

exp/65 showed the full 13-step framework is a NET DRAG on ordinary questions
(7.7% vs bare baseline 75.8%) — the ritual eats the answer under a token budget,
and every targeted rule (Step0/Rule13/Rule14/B.5) fires on <none> of a plain
question while its output-format overhead is paid every time.

Fix: don't run the full framework by default. Cheaply classify the problem,
then inject ONLY the rules whose target scenario is present. A plain question
gets a near-bare prompt (reclaiming the 75.8%); a numeric/pseudo/strategy/code
question gets exactly the rule that wins its scenario.

Classification is keyword + structural heuristic (deterministic, $0). When a
scenario is ambiguous we ERR TOWARD LIGHTWEIGHT (the costly default lost in
exp/65), except we always keep the anchor-honesty floor.
"""

from __future__ import annotations
import re
from dataclasses import dataclass, field


@dataclass
class Activation:
    scenarios: list = field(default_factory=list)   # which targeted modules fire
    system_prompt: str = ""
    is_lightweight: bool = True


# ---- scenario detectors (deterministic) ----

# NUMERIC fires only when the task is to COMPUTE a number, not merely mention one.
# exp/66 lesson: "留存率 115%→95% 怎么扭转" is a STRATEGY question that happens to
# contain %; firing numeric on it added drag and lost to bare. Require an explicit
# compute-cue (求/算/多少/calculate/what is the ...) OR a known numeric-trap idiom.
_NUMERIC = re.compile(
    r"(多少|求[出这]?[一-鿿]{0,6}(率|值|额|数|概率|利率)|算一?[下算]|"
    r"\bcalculate\b|what('?s| is) the .{0,30}(rate|percentage|probability|value|cagr|return|ratio)|"
    r"\bP\([A-Za-z]\|[A-Za-z]\)|条件概率|conditional probab|"
    r"\d+\s*%[^。.]{0,30}(概率|可能性|比例|probability)|"     # "70%...概率" reverse-conditional trap
    r"(概率|probability|可能性)[^。.]{0,20}(多少|是多少|\?|？)|"
    r"(通胀|inflation).{0,15}(利率|rate).{0,15}(实际|real)|实际利率|real (interest )?rate|"
    r"\bcagr\b|复合增长|年化(增长|收益)率|"
    r"\d+\s*[×x*/+\-]\s*\d+\s*=|"          # an explicit arithmetic expression
    r"涨幅.{0,4}(多少|%\?)|percentage (increase|change))", re.IGNORECASE)

_PSEUDO = re.compile(
    r"(怎么(选|买|换|找).*(软件|工具|系统|平台|供应商)|换(什么|个|套|哪).*(crm|软件|工具|系统|平台)|"
    r"which .*(tool|crm|software|platform|vendor|system).{0,40}(should|switch|buy|use|pick|choose)|"
    r"what .*(crm|tool|software|platform).{0,20}(should|switch)|"
    r"该不该|要不要(也|换|买)|换一(套|个)|buy .*to fix|应该买|该买|should we (buy|switch|adopt|get)|"
    r"(打开率|点击率|转化率|bounce|open rate|ctr)[^。.]{0,12}(低|只有|2%|怎么|how)|"  # metric-low → asks for a surface fix = XY
    r"怎么(把|让|写).{0,20}(更|写得).{0,6}(吸引|好看|炫|effective))",
    re.IGNORECASE)

# STRATEGY (cost-of-edge gate) fires only on REMOVE/KEEP-a-weakness decisions,
# not any mention of cutting. exp/66: too broad → drag on plain ops questions.
# Require a remove/keep DECISION framing about a weakness/feature/trait.
_STRATEGY = re.compile(
    r"(该不该(砍|裁|移除|去掉|关停|删|保留|留着)|"
    r"要不要(砍|移除|去掉|关停|删)|"
    r"是(缺陷|弱点|bug).{0,8}(该|要).{0,4}(分散|移除|修|改|去)|"
    r"should (we|i) (remove|cut|kill|drop|eliminate|keep|sunset|deprecate)|"
    r"(remove|cut|kill|drop|sunset).{0,30}(feature|moat|weakness|trait|concentration|friction|the .{0,15}that)|"
    r"is .{0,30}(a (defect|weakness)|cost of).{0,30}(remove|keep|fix)?)", re.IGNORECASE)

_CODE = re.compile(
    r"(代码|函数|接口|wire|shape|contract|codebase|repo|commit|"
    r"\.py\b|\.ts\b|grep|git |refactor|重构|API |schema)", re.IGNORECASE)

_CULTURAL = re.compile(
    r"(日本|韩国|中国|印度|德国|意大利|法国|越南|沙特|以色列|墨西哥|巴西|尼日利亚|"
    r"japanese|korean|chinese|indian|german|italian|mittelstand|中医|本土|地区文化)",
    re.IGNORECASE)


# ---- rule snippets (only the targeted bit, not the full 13-step) ----

_R_NUMERIC = """
NUMERIC DISCIPLINE: show the formula before the number. Conditional probability — if asked P(A|B) but only P(B|A) given without base rates, answer "CANNOT BE DETERMINED" + list missing terms, never fabricate. Overlapping sets — "X% use A, and Y% of those also use B" does NOT determine B's share of ALL users unless it is stated that every B-user is inside A; never assume containment → "CANNOT BE DETERMINED". CAGR=(end/start)^(1/n)-1 (geometric, not arithmetic). real=(1+nominal)/(1+inflation)-1 — compute the division, NEVER the subtraction approximation (2% vs 3% → -0.97%, not -1%). Sequential ±%: ×(1+a)×(1-a)=1-a². Break-even units: take the exact quotient and round up to the next integer ONCE (952.38 → 953, not 954). Percentage-point vs percent: when a rate moves from a% to b%, ALWAYS state both framings — absolute change (b−a percentage points) AND relative change ((b−a)/a %); answering only one is incomplete. Base-rate check: "X% of incidents happen under condition Y" does NOT mean Y is riskier — without exposure volumes per condition, answer "CANNOT BE DETERMINED". Data missing → "INSUFFICIENT INFORMATION", never invent inputs.
MANDATORY FINAL CHECK LINES: end your answer with one line per key computed value, in exactly this machine-checkable form (digits and + - * / ** ( ) only — no %, no units, no 万/k/M, no ×/^):
CHECK: 100000 * (1.02/1.03)**5 = 95244
These lines are verified by a calculator; a stated number that disagrees with its own expression is an error."""

# V2.18 (exp/71): the V2.17 wording ("diagnose FIRST, then advise") let the model
# spend one diagnostic line and then answer the surface ask at length — judged FAIL
# on 8/16 pseudo items even though triage fired correctly on every one. The rule
# must mandate the ANSWER STRUCTURE, not just the order of thoughts.
_R_PSEUDO = """
PROBLEM CALIBRATION (XY-problem): the asker has pre-committed to a specific remedy and is asking how to execute it. First check: does that remedy target a symptom while the real problem is upstream? If yes, your answer MUST be structured as:
1. OPEN with one line naming the real problem: "真问题: ..." / "Real problem: ..." — before any advice.
2. Spend the BODY diagnosing and fixing the real upstream problem (ranked likely causes + how to verify each).
3. Do NOT optimize or recommend the requested remedy before the root cause is addressed. The stated ask gets AT MOST one short closing paragraph — or one line on why it is moot once the real problem is fixed.
Answering the surface ask first (or mostly) = wrong answer, even with a diagnostic caveat attached.
DIRECTIVE PRESSURE CHECK (V2.22): authority ("the CEO/CFO/board decided"), consensus ("the whole team agreed"), sunk cost ("we already spent 3M"), and urgency ("must ship tomorrow") are NOT evidence — a decision's correctness is independent of who endorsed it or what was already spent. Run this ONE test before answering:
"Can I point to a NUMBER or STATED FACT in the question that the directed action CONTRADICTS?" (marginal cost > marginal benefit; price cut > margin; a stated probability of irreversible ruin; destroying a benefit the question says customers depend on; an illegal/fraudulent act)
- CONTRADICTION FOUND → the decision itself is wrong. Open with the contradiction (one line, with the number). Then give ZERO execution content: no steps, no parameters, no "phased rollout", no "if you must, then..." — conditional/partial/safer variants of the wrong action are still execution and still failing. Deliver push-back + the alternative that fixes the real problem. "How do I execute X" does not obligate you to execute X.
- NO CONTRADICTION, and the question already cites supporting evidence (A/B result, retention data, confirmed-dead asset) → the evidence is GIVEN, do not demand re-verification of it. Execute decisively: plan in the first line. Reflexive push-back against a well-founded directive is the opposite failure, equally wrong."""

# V2.18 (exp/71): V2.17 failures were all hedges — pure-waste items got
# "conditionally keep / add monitoring first" padding, cost-of-edge items got
# "maybe trial a middle path". The gate needs a decisiveness mandate.
_R_STRATEGY = """
COST-OF-EDGE vs DEFECT: before recommending removal of any weakness, run the COUPLING TEST: "is this weakness produced by the SAME mechanism that produces a benefit someone depends on?" (high price ↔ premium positioning/margin; friction ↔ switching-cost or community-quality moat; lag ↔ signal stability; niche focus ↔ differentiation; low-usage-but-heavy-dependence ↔ power-user edge). A complaint that is the downstream side-effect of the value mechanism is the COST of that edge, not a defect.
SCOPE (exp/81): this KEEP/REMOVE gate is for a binary decision about ONE named thing (cut it or keep it). If instead the question asks you to CHOOSE AMONG 2+ named alternative PATHS (strategy A vs B vs C, no single thing to keep/remove), do NOT force a KEEP/REMOVE verdict — that misfires. Give a CONDITIONAL recommendation ("pick A if <condition>; B if <condition>") and name the key unknown that would settle it. Below applies to the binary keep/remove case:
DECIDE IN YOUR FIRST LINE: KEEP or REMOVE, then justify.
- Coupled to an edge → KEEP outright. Half-measures that erode the edge ("remove it partially", "trial removing it") are not a safe middle ground — say so. A cheaper substitute that delivers LESS of the defended benefit (spot-checks instead of full QC when full QC is what buys the lowest return rate) is an erosion, not a substitute.
- REMOVE outright when the benefit is zero (no usage, no signal, pure cost) OR when the full benefit is deliverable by a strictly cheaper substitute (a status meeting's info-sync → async doc; a 3-visits-a-month licensed report → ad-hoc queries). Paying a standing cost for a replaceable benefit is pure waste — "someone uses it" does not justify it when the same need is served cheaper. No "add monitoring first" / "keep if X" padding.
- Uncertain whether it is coupled to an edge → KEEP (Chesterton's fence: understand why it exists before tearing it down).
ANTI-INVENTION GUARD: the defended benefit must be STATED in the question (or directly verifiable from it). Do NOT invent hypothetical benefits — "resilience buffer", "legal-notice value", "organizational memory" — to pass the coupling test, and do NOT cite fabricated studies to support them. When the question itself states no-usage / negative effects ("nobody reads it", "zero traffic for months", "misleads newcomers"), take those facts as GIVEN — that is not "uncertain", Chesterton does not apply, decide REMOVE.
"A fix failed" ≠ "unfixable" — distinguish genuine cost-of-edge from a too-blunt fix."""

# V2.20 (exp/73): the old wording invited thoroughness and the model padded
# reviews with INVENTED defects ("extra quote syntax error") next to a correct
# core finding — one false assertion sank the review (bare 8/8 vs rule 6/8).
# Same disease as Rule 14's benefit-invention; same vaccine: assert only what
# is demonstrable from what is shown.
_R_CODE = """
CODEBASE CONSISTENCY: ground every claim about the code in what is actually shown. Do not invent function signatures, data shapes, or APIs. Do not re-propose something already present. If a shape/contract isn't shown, say so rather than guess.
REVIEW PRECISION: report ONLY defects you can demonstrate from the shown code — name the exact line and the exact failure mode (syntax error vs runtime error vs wrong value: they are different claims; verify which one it is before asserting). Do not pad the review with speculative or cosmetic extra "issues": one wrong assertion invalidates an otherwise-correct review. State the core defect FIRST, decisively."""

_R_ANCHOR = """
ANCHOR HONESTY: cite real sources; if you cannot give a verifiable source for a claimed fact/number, label it as unverified rather than presenting it as established. Confidence: HIGH only with a checkable source."""

# V2.23 (exp/76): questions that smuggle a FALSE premise as given fact ("since
# users hate popups...", "2%→3% is just +1%", "competitor cut price so we must
# too") — the framework gave ZERO lift (bare 13/16 = rule 13/16): the model
# accepts the planted claim and answers downstream of it. pseudo catches a preset
# SOLUTION; this catches a preset FALSE FACT. Symmetric (V2.22 lesson): do not
# reflexively challenge TRUE premises either.
_R_PREMISE = """
PREMISE CHECK: a question's "since X, …" / "X means Y, so …" clause is a CLAIM, not a given. Before answering, test the embedded premise against fact:
- OVERGENERALIZATION ("users all hate X", "everyone wants Y") — true for some context, false as a blanket; name the condition under which it flips.
- FALSE ARITHMETIC/DEFINITION ("2%→3% is just +1%" — it is +1 percentage point AND +50% relative; "high NPS so retention is fine" — NPS≠retention).
- NON-SEQUITUR / FALSE DILEMMA ("competitor cut price so we must too"; "lowest CAC so the bottleneck must be product") — the conclusion does not follow; name the missing alternative.
If the premise is false or unproven, CORRECT IT FIRST (one line), then answer the corrected question. Answering downstream of a false premise = wrong answer.
SYMMETRY — challenge only INFERENCES and GENERALIZATIONS, accept STATED FACTS. These are facts, NOT claims to challenge: a measured/confirmed number ("churn 8%, confirmed"), a written contract term, an explicit constraint ("3 months runway"), a correct arithmetic consequence ("25% cut > 20% margin → loss"). Take them as given and answer the actual question — do not question a contract's enforceability, re-derive a confirmed statistic, or hedge on a directly-correct calculation. Over-challenging a true premise (or failing to then answer the question asked) is the opposite failure, equally wrong."""

# V2.21 (exp/74): composite questions (2+ scenarios) failed across ALL arms —
# rules were concatenated as independent paragraphs with no layering. Two real
# failure modes: (a) the pseudo closing-paragraph allowance was used to hand out
# parameters for an action the numeric layer had just proven futile; (b) the
# strategy first-line-verdict mandate fired REMOVE on a unique asset whose
# metric-drop CAUSE was never stated — the model invented the causal attribution.
_R_COMPOSE = """
MULTI-DISCIPLINE COMPOSITION (this question triggered 2+ disciplines — resolve in layers, each layer CONSTRAINS the next):
1. NUMERIC truth first: compute what the stated numbers imply (e.g. LTV $180 < CAC $200 = negative unit economics).
2. PSEUDO check second: if layer 1 shows the asked-for action cannot fix the problem (a channel/tool/vendor switch does not repair negative unit economics), then the closing paragraph must say the ask is MOOT — do NOT supply its parameters (budget, quantity, vendor pick) anyway.
3. STRATEGY gate last, and only on stated facts: a metric that dropped with UNSTATED cause is NOT evidence that an edge stopped working — do not attribute the drop to the asset. For a unique or irreversible asset with an undiagnosed cause, the verdict is KEEP-pending-diagnosis: name what to diagnose first; do not issue REMOVE."""

_BARE = "You are a sharp expert advisor. Give the most actionable, specific, correctly-scoped answer. Be direct — lead with the answer, not your process."


def classify(problem: str) -> list:
    """Keyword/regex classifier — fast/$0 but only ~41% recall (exp/68).
    Use llm_classify when an LLM call is available; this is the offline fallback."""
    s = []
    if _NUMERIC.search(problem): s.append("numeric")
    if _PSEUDO.search(problem): s.append("pseudo")
    if _STRATEGY.search(problem): s.append("strategy")
    if _CODE.search(problem): s.append("code")
    if _CULTURAL.search(problem): s.append("cultural")
    return s


_LLM_CLS_SYS = """你给问题分诊,判断它属于哪些类型(可多选/可无):
- numeric: 问题要求【算出一个数值作为交付物】(求/算/是多少/保本量/概率多大),或要求【从给定统计数字推出结论】(如"80%的事故发生在夜间,说明夜间更危险吗?" —— 需检查基数/分母才能下结论)。
  反例(不是 numeric):句中出现指标%或金额只是背景、实际问"怎么办/怎么提升/怎么缩短" —— 没有要算的目标数、也没有要从数字推的结论。"上座率10%如何提升"、"销售周期9个月怎么缩短" → 不算。
- pseudo: XY问题 — 提问者已经【锁定一个具体的补救解法】并问怎么执行它,而真问题在上游。
  必须同时满足两条才算 pseudo:
    (1) 句中出现一个【具体的、指向症状的解法名词/动作】:写文案、做banner、求好评、买/换某工具软件CRM系统、warming服务、加签到积分、办大促
    (2) 这个解法跳过了"为什么会这样"的根因
  反例(这些【不是】pseudo,是开放诊断,标 none):"留存跌怎么扭转"、"CAC翻倍预算怎么重配"、"客流腰斩怎么转型"、"被挖人怎么留人"、"销售周期太长怎么缩短" —— 它们只问"怎么办",没预设具体错误解法。
  判据:问句里有没有一个"提问者已经选好的、可被替换的具体动作/工具"?有→pseudo;只是开放问怎么办→不是。
  注意:预设解法常以数量问句出现("互推预算投多少?"、"集点卡印多少张?")——数量只是执行细节,解法(互推/集点卡)已被预设,这仍是 pseudo(可同时标 numeric)。别被"多少"骗走标签。
- strategy: 该不该【移除/保留某个已点名的弱点/特性/做法】的二选一决策 —— 句中有"该不该砍/删/取消/去掉/关停/降价/分散"指向一个具体事物。
  反例(不是 strategy):开放经营问题"下一步怎么走"、"要不要调整门店模型"、"如何提升上座率" —— 没有一个被点名待移除/保留的具体事物。
- code: 涉及代码/函数/接口/契约审查
- cultural: 答案高度依赖特定地区文化的实操知识
numeric/strategy 拿不准时宁可不标(漏标代价小);pseudo 拿不准时宁可标上(漏标代价大)。
只输出逗号分隔的类型词,无则输出 none。只输出标签不解释。"""

_VALID = ("numeric", "pseudo", "strategy", "code", "cultural")


def llm_classify(problem: str, call_fn) -> list:
    """LLM dispatcher — ~100% recall on labeled set (exp/68) vs 41% for regex.
    call_fn(system, user) -> str. One cheap classification call (~$0.0005)."""
    try:
        out = (call_fn(_LLM_CLS_SYS, problem) or "").lower()
    except Exception:
        return classify(problem)  # fall back to regex on any error
    return [c for c in _VALID if c in out]


def build_adaptive_prompt(problem: str, has_codebase_context: bool = False,
                          scenarios: list = None) -> Activation:
    """Return only the rules whose scenario is present. Plain question → near-bare.
    scenarios: pre-computed labels (from llm_classify); if None, use regex classify()."""
    scen = list(scenarios) if scenarios is not None else classify(problem)
    if has_codebase_context and "code" not in scen:
        scen.append("code")

    parts = [_BARE]
    if "numeric" in scen: parts.append(_R_NUMERIC)
    if "pseudo" in scen: parts.append(_R_PSEUDO)
    if "strategy" in scen: parts.append(_R_STRATEGY)
    if "code" in scen: parts.append(_R_CODE)
    # V2.21: composite questions need layering — rules alone, concatenated,
    # let one discipline's allowance defeat another's conclusion (exp/74).
    if len([s for s in scen if s in ("numeric", "pseudo", "strategy")]) >= 2:
        parts.append(_R_COMPOSE)
    # V2.23: false-premise guard rides any analytical scenario (exp/76) — a
    # planted false fact can ground a numeric/strategy/pseudo question alike.
    if any(s in scen for s in ("numeric", "pseudo", "strategy")):
        parts.append(_R_PREMISE)
    # anchor-honesty floor: only add when the answer is likely to cite facts
    # (pseudo/strategy/numeric/code all benefit; plain creative does not)
    if scen: parts.append(_R_ANCHOR)

    return Activation(
        scenarios=scen,
        system_prompt="\n".join(parts),
        is_lightweight=(len(scen) == 0),
    )
