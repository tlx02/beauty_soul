"""V2.6 Full Integration — Orchestrates V2.5+AW + Cluster A/B/C/D fixes.

Production V2.6 stack:
    V2.4.4a prompt (reasoning)
    + B.1 anchor verifier
    + B.2 numeric verifier
    + B.3.1 retrieval memory (sentence-embeddings)
    + B.4 formal verifier (probability)
    + AW creative critic
    + Cluster A practitioner cache (subdomain specialists)
    + Cluster B multi-agent debate (creative vision)
    + Cluster C live web retrieval (post-cutoff)
    + Cluster D cultural cache (cultural specificity)

Projected: 95-97% W-L-T on n=1000 (up from V2.5+AW 93%).
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from .creative import auto_score
from .multi_agent_debate import run_debate
from .live_retrieval import lookup_with_retrieval, post_cutoff_indicators


@dataclass
class V26Recommendation:
    """Final V2.6 output."""
    original_recommendation: str
    aw_score: int
    aw_classification: str
    debate_triggered: bool
    debate_winner: str
    final_recommendation: str
    final_score: int
    cluster_a_anchors_used: list[str]
    cluster_d_anchors_used: list[str]
    post_cutoff_flagged: bool
    confidence: str  # HIGH / MODERATE / LOW / UNKNOWN

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def load_v26_caches() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Load V2.6 Cluster A + D caches."""
    cache_dir = Path(__file__).parent / "calibration"
    practitioner = json.loads((cache_dir / "practitioner-cache-v26.json").read_text())
    cultural = json.loads((cache_dir / "cultural-practitioner-cache-v26.json").read_text())
    return practitioner["anchors"], cultural["anchors"]


def find_relevant_anchors(
    recommendation: str,
    anchors: list[dict[str, Any]],
    max_results: int = 3,
) -> list[str]:
    """Find anchors from cache most relevant to the recommendation.

    Production: cosine similarity via sentence-embeddings.
    Offline: keyword-based matching against subdomain/source field.
    """
    rec_lower = recommendation.lower()
    matches = []
    for anchor in anchors:
        source = anchor.get("source", "").lower()
        datum = anchor.get("datum", "").lower()
        subdomain = anchor.get("subdomain", anchor.get("culture", "")).lower()

        # Keyword overlap
        score = 0
        for word in source.split() + subdomain.split():
            if len(word) >= 4 and word in rec_lower:
                score += 1
        if score > 0:
            matches.append((score, anchor["source"]))

    matches.sort(reverse=True)
    return [src for _, src in matches[:max_results]]


def integrate_v26(
    recommendation: str,
    domain_context: str = "",
) -> V26Recommendation:
    """Run full V2.6 integration on a V2.5 recommendation.

    Args:
        recommendation: V2.5 final recommendation text
        domain_context: optional domain hint (e.g., 'Japanese B2B', 'rare oncology')

    Returns:
        V26Recommendation with all V2.6 layers applied
    """
    # Step 1: AW Creative Critic score
    aw_score_obj = auto_score(recommendation)

    # Step 2: Trigger debate if AW score < 7 (BUZZWORD/AMBIGUOUS)
    debate_triggered = aw_score_obj.total < 7
    debate_winner = "original"
    final_recommendation = recommendation
    final_score = aw_score_obj.total

    if debate_triggered:
        debate_result = run_debate(recommendation, margin=1)
        if debate_result.winner != "original":
            # V2.13 SUBTRACTIVE FIX (experiments/54 real-API finding): the
            # pattern-template alternatives score high on AW's own markers
            # (they embed "instead of"/"makes obsolete"/named analogs by
            # construction) but are generic slot-fills — replacing real
            # output with them produced WORSE text in production
            # ("customers will say Trinity 'changed how we do this'").
            # Templates may only ANNOTATE, never REPLACE. The original
            # recommendation is kept; the template is appended as a labeled
            # suggestion so a human can judge it.
            debate_winner = debate_result.winner
            final_recommendation = (
                recommendation
                + f"\n\n--- [AW critic: score {aw_score_obj.total}/12, below 7. "
                f"A '{debate_result.winner}'-style reframe MIGHT be stronger — "
                "template suggestion below; judge it yourself, it was NOT "
                "auto-applied (V2.13)] ---\n"
                + debate_result.winning_text
            )
            # Score stays the ORIGINAL's — templates no longer launder the score.
            final_score = aw_score_obj.total

    # Step 3: Look up Cluster A practitioner anchors
    practitioner_anchors, cultural_anchors = load_v26_caches()
    cluster_a_used = find_relevant_anchors(final_recommendation + " " + domain_context, practitioner_anchors)

    # Step 4: Look up Cluster D cultural anchors
    cluster_d_used = find_relevant_anchors(final_recommendation + " " + domain_context, cultural_anchors)

    # Step 5: Check post-cutoff (Cluster C trigger)
    post_cutoff_flagged = post_cutoff_indicators(final_recommendation + " " + domain_context)

    # Step 6: Compute final confidence
    if final_score >= 8 and (cluster_a_used or cluster_d_used) and not post_cutoff_flagged:
        confidence = "HIGH"
    elif final_score >= 7:
        confidence = "MODERATE"
    elif final_score >= 5:
        confidence = "LOW"
    else:
        confidence = "UNKNOWN"

    return V26Recommendation(
        original_recommendation=recommendation,
        aw_score=aw_score_obj.total,
        aw_classification=aw_score_obj.classification,
        debate_triggered=debate_triggered,
        debate_winner=debate_winner,
        final_recommendation=final_recommendation,
        final_score=final_score,
        cluster_a_anchors_used=cluster_a_used,
        cluster_d_anchors_used=cluster_d_used,
        post_cutoff_flagged=post_cutoff_flagged,
        confidence=confidence,
    )


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(description="V2.6 Full Integration")
    parser.add_argument("recommendation", help="V2.5 recommendation to enhance")
    parser.add_argument("--domain", default="", help="Optional domain context")
    args = parser.parse_args()

    result = integrate_v26(args.recommendation, args.domain)
    print(json.dumps(result.as_dict(), indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
