"""Trinity Protocol V2.5 Phase B.2 — Numeric Claim Verifier (code execution).

Verifies numeric / arithmetic claims inside V2.4+ trace gate findings by:
  1. Extracting the math being asserted (Claude, no tools)
  2. Re-deriving the value independently (Claude with code-exec tool, OR
     local Python sandbox)
  3. Comparing computed vs claimed within tolerance
  4. Returning VERIFIED / ERROR / UNPARSEABLE with derivation transcript

This is the Phase B.2 mechanism in the V2.5 paradigm: prompt + verifier loop
augmented with TOOL USE (here: arithmetic / code) for grounded fact-checking
of numeric content.

Usage:
    from code_exec_pass import verify_numeric_claim
    result = verify_numeric_claim("$50M / 5 years = $5M per year average")
    # → {"classification": "ERROR", "computed_value": 10_000_000,
    #    "claimed_value": 5_000_000, "delta_ratio": 1.0, "derivation": ...}

    # Or run calibration:
    python code_exec_pass.py --calibration calibration/numeric-known-correct.json \\
                              calibration/numeric-known-incorrect.json

Design notes:
- Independent Python execution serves as the truth oracle. The verifier
  generates Python code that re-derives the claim, then runs it in a sandboxed
  exec() call (no I/O, no network, no file access).
- For Anthropic Claude API integration with native code-exec tool, swap the
  exec_local() function with the tool_use loop.
- Classification ladder:
    VERIFIED        — claimed and computed match within tolerance
    PARTIAL_VERIFIED — match within 2x tolerance (often rounding artifact)
    ERROR           — claimed and computed differ outside tolerance
    UNPARSEABLE     — could not extract math from claim text
"""

from __future__ import annotations

import argparse
import ast
import json
import math
import os
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

try:
    import anthropic
    _HAS_ANTHROPIC = True
except ImportError:
    _HAS_ANTHROPIC = False


DEFAULT_MODEL = "claude-opus-4-8"
DEFAULT_TOLERANCE = 0.01  # 1% within-tolerance considered VERIFIED


EXTRACT_PROMPT = """You will be given a text containing a numeric claim. Extract:
  1. The claimed_value (the number the text asserts as the answer)
  2. The math_to_derive (a clear Python expression or calculation that should produce the claimed value)
  3. Any specific tolerance hint (e.g., "approximately", "~", "around" suggests tolerance allowed)

Return ONLY a JSON object with keys [claimed_value, math_to_derive, tolerance_hint]. No prose. The math_to_derive must be valid Python expression using only basic arithmetic (+, -, *, /, **, math.sqrt, math.log).

If the claim has no extractable numeric assertion, return {"claimed_value": null, "math_to_derive": null, "tolerance_hint": null}.

Claim text to extract from:
---
{claim_text}
---
"""


@dataclass
class NumericVerdict:
    claim_text: str
    classification: str  # VERIFIED / PARTIAL_VERIFIED / ERROR / UNPARSEABLE
    claimed_value: float | None
    computed_value: float | None
    delta_ratio: float | None  # |computed - claimed| / max(|claimed|, |computed|, 1)
    math_to_derive: str | None
    derivation_log: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def safe_eval(expr: str) -> float | None:
    """Evaluate a math expression with restricted ast nodes (no I/O, no calls except math.*)."""
    if not expr:
        return None
    try:
        tree = ast.parse(expr, mode="eval")
        for node in ast.walk(tree):
            # Only allow numeric literals, binary ops, unary ops, math module attrs
            allowed = (
                ast.Expression, ast.BinOp, ast.UnaryOp, ast.Num, ast.Constant,
                ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow,
                ast.USub, ast.UAdd,
                ast.Call, ast.Name, ast.Attribute, ast.Load,
            )
            if not isinstance(node, allowed):
                return None
            if isinstance(node, ast.Call):
                func = node.func
                # Allow math.X(args) where X is in a safe whitelist
                if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name) and func.value.id == "math":
                    if func.attr not in {"sqrt", "log", "log2", "log10", "pow", "exp", "ceil", "floor", "trunc"}:
                        return None
                else:
                    return None
            if isinstance(node, ast.Name) and node.id != "math":
                return None
            if isinstance(node, ast.Attribute) and node.attr not in {
                "sqrt", "log", "log2", "log10", "pow", "exp", "ceil", "floor", "trunc"
            } and not (isinstance(node.value, ast.Name) and node.value.id == "math"):
                return None
        return float(eval(compile(tree, "<expr>", "eval"), {"math": math, "__builtins__": {}}, {}))
    except Exception:
        return None


def extract_with_claude(client: anthropic.Anthropic, claim_text: str, model: str) -> dict[str, Any]:
    """Step 1 — Claude extracts {claimed_value, math_to_derive, tolerance_hint}."""
    response = client.messages.create(
        model=model,
        max_tokens=512,
        temperature=0.0,
        messages=[{"role": "user", "content": EXTRACT_PROMPT.format(claim_text=claim_text)}],
    )
    text = response.content[0].text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1]
        if text.endswith("```"):
            text = text.rsplit("```", 1)[0]
        text = text.strip()
        if text.startswith("json"):
            text = text[4:].strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {"claimed_value": None, "math_to_derive": None, "tolerance_hint": None}


def verify_numeric_claim(
    claim_text: str,
    client: anthropic.Anthropic | None = None,
    model: str = DEFAULT_MODEL,
    tolerance: float = DEFAULT_TOLERANCE,
) -> NumericVerdict:
    """Main entry: verify a numeric claim against its own arithmetic.

    Two paths:
    - With Anthropic client (production): Claude extracts math, then safe_eval computes
    - Without client (offline calibration test): caller supplies math_to_derive directly
    """
    derivation_log = []

    if client is None or not _HAS_ANTHROPIC:
        derivation_log.append("[offline mode] No Anthropic client; calibration mode expected.")
        return NumericVerdict(
            claim_text=claim_text,
            classification="UNPARSEABLE",
            claimed_value=None,
            computed_value=None,
            delta_ratio=None,
            math_to_derive=None,
            derivation_log="\n".join(derivation_log),
        )

    derivation_log.append(f"Step 1 [extract via Claude]: claim_text={claim_text!r}")
    extracted = extract_with_claude(client, claim_text, model)
    derivation_log.append(f"Step 1 result: {extracted!r}")

    claimed = extracted.get("claimed_value")
    math_expr = extracted.get("math_to_derive")

    if claimed is None or math_expr is None:
        return NumericVerdict(
            claim_text=claim_text,
            classification="UNPARSEABLE",
            claimed_value=None,
            computed_value=None,
            delta_ratio=None,
            math_to_derive=math_expr,
            derivation_log="\n".join(derivation_log),
        )

    derivation_log.append(f"Step 2 [safe_eval]: math_to_derive={math_expr!r}")
    computed = safe_eval(math_expr)
    derivation_log.append(f"Step 2 result: computed={computed!r}")

    if computed is None:
        return NumericVerdict(
            claim_text=claim_text,
            classification="UNPARSEABLE",
            claimed_value=float(claimed),
            computed_value=None,
            delta_ratio=None,
            math_to_derive=math_expr,
            derivation_log="\n".join(derivation_log),
        )

    claimed_f = float(claimed)
    denominator = max(abs(claimed_f), abs(computed), 1.0)
    delta_ratio = abs(computed - claimed_f) / denominator

    derivation_log.append(f"Step 3: claimed={claimed_f}, computed={computed}, delta_ratio={delta_ratio:.4f}, tolerance={tolerance}")

    if delta_ratio <= tolerance:
        classification = "VERIFIED"
    elif delta_ratio <= tolerance * 2:
        classification = "PARTIAL_VERIFIED"
    else:
        classification = "ERROR"

    derivation_log.append(f"Step 4: classification={classification}")

    return NumericVerdict(
        claim_text=claim_text,
        classification=classification,
        claimed_value=claimed_f,
        computed_value=computed,
        delta_ratio=delta_ratio,
        math_to_derive=math_expr,
        derivation_log="\n".join(derivation_log),
    )


def run_calibration(
    known_correct_path: Path,
    known_incorrect_path: Path,
    model: str = DEFAULT_MODEL,
    tolerance: float = DEFAULT_TOLERANCE,
) -> dict[str, Any]:
    """Run calibration on a benchmark set; produce confusion matrix."""
    if not _HAS_ANTHROPIC or not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("Calibration requires ANTHROPIC_API_KEY and anthropic SDK.")

    client = anthropic.Anthropic()
    correct_items = json.loads(known_correct_path.read_text())
    incorrect_items = json.loads(known_incorrect_path.read_text())

    results = {"TP": 0, "FP": 0, "TN": 0, "FN": 0, "details": []}

    for item in correct_items:
        verdict = verify_numeric_claim(
            item["claim_text"], client=client, model=model, tolerance=item.get("tolerance", tolerance)
        )
        is_verified = verdict.classification in ("VERIFIED", "PARTIAL_VERIFIED")
        if is_verified:
            results["TP"] += 1
        else:
            results["FN"] += 1
        results["details"].append({
            "id": item["id"],
            "ground_truth": "VERIFIED",
            "classification": verdict.classification,
            "match": is_verified,
            "claimed": verdict.claimed_value,
            "computed": verdict.computed_value,
            "delta_ratio": verdict.delta_ratio,
        })

    for item in incorrect_items:
        verdict = verify_numeric_claim(item["claim_text"], client=client, model=model, tolerance=tolerance)
        is_error = verdict.classification == "ERROR"
        if is_error:
            results["TN"] += 1
        else:
            results["FP"] += 1
        results["details"].append({
            "id": item["id"],
            "ground_truth": "ERROR",
            "classification": verdict.classification,
            "match": is_error,
            "claimed": verdict.claimed_value,
            "computed": verdict.computed_value,
            "delta_ratio": verdict.delta_ratio,
        })

    tp_rate = results["TP"] / len(correct_items) if correct_items else 0.0
    tn_rate = results["TN"] / len(incorrect_items) if incorrect_items else 0.0
    results["summary"] = {
        "TP_rate": tp_rate,
        "TN_rate": tn_rate,
        "combined_accuracy": (results["TP"] + results["TN"]) / (len(correct_items) + len(incorrect_items)),
        "rule_11_pass": tp_rate >= 0.8 and tn_rate >= 0.8,
    }
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description="V2.5 Phase B.2 — numeric claim verifier")
    parser.add_argument("--calibration", nargs=2, metavar=("KNOWN_CORRECT", "KNOWN_INCORRECT"),
                        help="Run calibration benchmark")
    parser.add_argument("--claim", help="Verify a single claim text")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--tolerance", type=float, default=DEFAULT_TOLERANCE)
    args = parser.parse_args()

    if args.calibration:
        known_correct = Path(args.calibration[0])
        known_incorrect = Path(args.calibration[1])
        results = run_calibration(known_correct, known_incorrect, args.model, args.tolerance)
        print(json.dumps(results, indent=2))
        return 0 if results["summary"]["rule_11_pass"] else 1

    if args.claim:
        if not _HAS_ANTHROPIC or not os.environ.get("ANTHROPIC_API_KEY"):
            sys.exit("Single-claim mode requires ANTHROPIC_API_KEY")
        client = anthropic.Anthropic()
        verdict = verify_numeric_claim(args.claim, client=client, model=args.model, tolerance=args.tolerance)
        print(json.dumps(verdict.as_dict(), indent=2))
        return 0 if verdict.classification in ("VERIFIED", "PARTIAL_VERIFIED") else 1

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
