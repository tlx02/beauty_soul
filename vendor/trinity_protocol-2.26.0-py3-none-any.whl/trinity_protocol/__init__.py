"""Trinity Protocol V2.12 — Python SDK.

Production-deployable problem-solving framework with prompt + verifier tools + codebase-aware solving.

Quick start:
    >>> from trinity_protocol import solve
    >>> # Basic solve
    >>> print(solve("Design a supply chain strategy for a $5B electronics company"))
    >>> # codebase-aware solve (B.5 consistency verifier auto-runs when context present)
    >>> print(solve("Improve SoulMate Companion", file_paths=["services/soulmate/*.py"]))
    >>> print(solve("Refactor auth system", grep_query="authenticate", git_log=True))

Components:
    Layer 1 — Reasoning: V2.4.4a system prompt (see SYSTEM_PROMPT constant)
    Layer 2 — Anchor verifier (B.1): trinity_protocol.verifier
    Layer 3 — Numeric verifier (B.2): trinity_protocol.numeric
    Layer 4 — Retrieval memory (B.3.1): trinity_protocol.memory
    Layer 5 — Formal verifier (B.4): trinity_protocol.formal
    Layer 6 — Creative critic (AW): trinity_protocol.creative
    Layer 7 — Codebase-aware context (V2.11): file_paths + grep_query + git_log
    Layer 8 — Cross-vendor B.1 skeptic (V2.11): independent model verifies anchors
    Layer 9 — Codebase-consistency verifier (B.5, V2.12): independent judge flags
              recommendations that contradict / re-propose the gathered code reality.
              Auto-runs when codebase context is present. Closes the loop V2.11 opened
              (context fed IN, but nothing verified the output respected it).

V2.12 also removes the V2.11 codebase-reader silent caps (file count / file size /
grep lines were silently truncated) in favour of explicit, reported truncation, and
anchors grep/git to the repo root (git grep → respects .gitignore).

For full documentation: github.com/mozatyin/trinity-protocol
"""

__version__ = "2.26.0"

from .numeric import verify_numeric_claim as verify_numeric, safe_eval
from .formal import verify_probability_claim as verify_probability
from .creative import auto_score as score_creative, auto_score as auto_score_creative
from .multi_agent_debate import run_debate, PERSONAS
from .v26_integration import integrate_v26

__all__ = [
    "__version__",
    "solve",
    "verify_numeric",
    "safe_eval",
    "verify_probability",
    "score_creative",
    "auto_score_creative",
    "run_debate",
    "PERSONAS",
    "integrate_v26",
    "clarify",
    "SYSTEM_PROMPT",
]


def solve(
    problem: str,
    domain: str = "",
    model: str = None,
    backend: str = "auto",
    verbose: bool = False,
    return_dict: bool = False,
    max_tokens: int = 4096,
    version: str = "v224",
    ttc: bool = False,
    ttc_max_n: int = 10,
    verify_anchors: bool = False,
    file_paths: list = None,
    grep_query: str = None,
    git_log: bool = False,
    cross_vendor_skeptic: bool = False,
    verify_consistency: bool = None,
    verify_math: bool = True,
    adaptive: bool = True,
    clarifications: list = None,
):
    """One-line V2.12 full solver. Supports Anthropic + OpenRouter (DeepSeek).

    Usage:
        from trinity_protocol import solve

        # 简单 — 自动 detect backend (ANTHROPIC_API_KEY 或 OPENROUTER_API_KEY)
        print(solve("分析 NVDA 12 个月 outlook"))

        # 显式 OpenRouter + DeepSeek
        print(solve("分析 NVDA", backend="openrouter"))

        # 显式 model
        print(solve("分析 NVDA", model="deepseek/deepseek-chat"))
        print(solve("分析 NVDA", model="claude-opus-4-8"))

        # 详细 metadata
        print(solve("你的问题", verbose=True))

    Backend auto-detect:
        OPENROUTER_API_KEY 设置 → OpenRouter (deepseek/deepseek-chat default)
        ANTHROPIC_API_KEY 设置 → Anthropic (claude-opus-4-8 default)
        都设置 → OpenRouter 优先 (省钱)

    Args:
        problem: 问题
        domain: domain hint (e.g., "equity research NVDA")
        model: explicit model override
        backend: "auto" | "anthropic" | "openrouter"
        verbose: 显示 confidence / AW score / cost
        return_dict: 返回完整 dict 而非 text only
        max_tokens: 输出 token 上限
        verify_consistency: B.5 codebase-consistency verifier. None (default) =
            auto-run when codebase context is present; True/False to force.

    Returns:
        str (default) | dict (if return_dict=True)

    Performance estimates:
        claude-opus-4-8: ~97% on n=1000 (projected; opus-4-7 measured 96.7%)
        deepseek/deepseek-chat: ~90-93% projected (DeepSeek-V3 reasoning)
        claude-sonnet-4-6: ~94-95% projected
    """
    import os
    import re

    # Parse "V2.X 三体迭代 [problem]" prefix — auto-route version
    _prefix_re = re.compile(
        r'^\s*[vV]?(2\.\d+(?:\.\d+)?)\s*(?:三体迭代|trinity|三体)\s*[:：，,]?\s*',
        re.UNICODE,
    )
    _m = _prefix_re.match(problem)
    if _m:
        _ver_num = _m.group(1)
        problem = problem[_m.end():].strip()
        version = {
            "2.4": "v26", "2.5": "v26", "2.6": "v26",
            "2.7": "v27", "2.8": "v28-alpha", "2.9": "v29-alpha",
            "2.10": "v211", "2.11": "v211", "2.12": "v212", "2.13": "v213", "2.14": "v214", "2.15": "v215", "2.16": "v216", "2.17": "v217", "2.18": "v218", "2.19": "v219", "2.20": "v220", "2.21": "v221", "2.22": "v222", "2.23": "v223", "2.24": "v224",
        }.get(_ver_num, version)

    # V2.11: Gather codebase context if requested (V2.12: explicit truncation reporting)
    # V2.25 interactive: fold clarify Q&A into the problem before the V2.24 path.
    # held-out: on under-specified advisory questions, clarify-then-solve scores
    # 5/8 vs one-shot 0/8 (exp/85). One-shot path is unchanged when clarifications
    # is None — this is purely additive, opt-in.
    if clarifications:
        from .interactive import build_enriched_problem
        problem = build_enriched_problem(problem, clarifications)

    codebase_context = _gather_codebase_context(file_paths, grep_query, git_log)
    if codebase_context:
        problem = f"{problem}\n\n═══ CODEBASE CONTEXT ═══\n{codebase_context}"

    # Determine backend
    has_openrouter = bool(os.environ.get("OPENROUTER_API_KEY"))
    has_anthropic = bool(os.environ.get("ANTHROPIC_API_KEY"))

    if backend == "auto":
        if has_openrouter:
            backend = "openrouter"
        elif has_anthropic:
            backend = "anthropic"
        else:
            raise RuntimeError(
                "No API key found. Set one of:\n"
                "  export OPENROUTER_API_KEY=sk-or-...   (DeepSeek via OpenRouter, cheaper)\n"
                "  export ANTHROPIC_API_KEY=sk-ant-...   (Claude direct)"
            )

    # V2.17 adaptive activation: exp/65 proved the full 13-step framework is a
    # NET DRAG on ordinary questions. Default = classify the problem, inject ONLY
    # the rules whose target scenario is present; a plain question runs near-bare.
    _sys_override = None
    _activation = None
    if adaptive and version not in ("v28-alpha", "v28-beta", "v29-alpha"):
        from .adaptive import build_adaptive_prompt, llm_classify
        # V2.17: LLM dispatcher (100% recall vs 41% regex, exp/68) — one cheap
        # classification call routes the problem to only its targeted rules.
        _scen = None
        try:
            def _cls_call(system, user):
                if backend == "openrouter":
                    from openai import OpenAI
                    _c = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=os.environ["OPENROUTER_API_KEY"])
                    r = _c.chat.completions.create(model=model or "deepseek/deepseek-chat",
                        max_tokens=20, temperature=0,
                        messages=[{"role":"system","content":system},{"role":"user","content":user}])
                    return r.choices[0].message.content or ""
                else:
                    import anthropic
                    r = anthropic.Anthropic().messages.create(model=model or "claude-opus-4-8",
                        max_tokens=20, system=system, messages=[{"role":"user","content":user}])
                    return r.content[0].text if r.content else ""
            _scen = llm_classify(problem, _cls_call)
        except Exception:
            _scen = None  # build_adaptive_prompt falls back to regex
        _activation = build_adaptive_prompt(problem, has_codebase_context=bool(codebase_context), scenarios=_scen)
        _sys_override = _activation.system_prompt

    # Run via chosen backend
    if backend == "openrouter":
        recommendation, cost, in_tokens, out_tokens = _call_openrouter(
            problem, model or "deepseek/deepseek-chat", max_tokens, system_override=_sys_override
        )
    elif backend == "anthropic":
        recommendation, cost, in_tokens, out_tokens = _call_anthropic(
            problem, model or "claude-opus-4-8", max_tokens, system_override=_sys_override
        )
    else:
        raise ValueError(f"Unknown backend: {backend}. Use 'auto' / 'anthropic' / 'openrouter'.")

    # V2.6/V2.7/V2.8 orchestration — version-gated
    if version in ("v28-alpha", "v28-beta", "v29-alpha"):
        from .v28_integration import integrate_v28
        v28_result = integrate_v28(
            recommendation, domain_context=domain,
            ttc=(version == "v28-beta" or ttc),
            ttc_max_n=ttc_max_n,
        )
        # Convert V28Recommendation to compatible result shape
        class _CompatResult:
            def __init__(self, v28):
                self.final_recommendation = v28.final_recommendation
                self.aw_score = v28.aw_score
                self.aw_classification = v28.aw_classification
                self.debate_triggered = v28.debate_triggered
                self.debate_winner = v28.debate_winner
                self.cluster_a_anchors_used = v28.cluster_a_anchors_used
                self.cluster_d_anchors_used = v28.cluster_d_anchors_used
                self.post_cutoff_flagged = v28.post_cutoff_flagged
                self.confidence = v28.confidence
                # V2.8 specific
                self.estimated_tokens_saved = v28.estimated_tokens_saved
                self.ttc_enabled = v28.ttc_enabled
                self.ttc_rounds_run = v28.ttc_rounds_run
        result = _CompatResult(v28_result)
    else:
        # V2.6/V2.7 baseline (legacy)
        result = integrate_v26(recommendation, domain_context=domain)
        # Add V2.8 attribute defaults
        result.estimated_tokens_saved = 0
        result.ttc_enabled = False
        result.ttc_rounds_run = 0

    # V2.10 — B.1 inline anchor verification (opt-in via verify_anchors=True or cross_vendor_skeptic)
    b1_result = None
    if verify_anchors or cross_vendor_skeptic:
        from .b1_inline import run_b1_inline

        # V2.11: Cross-vendor skeptic uses a DIFFERENT vendor/model for B.1
        # If main is Anthropic → skeptic uses OpenRouter (DeepSeek)
        # If main is OpenRouter → skeptic uses Anthropic (Claude)
        if cross_vendor_skeptic:
            skeptic_backend = "anthropic" if backend == "openrouter" else "openrouter"
        else:
            skeptic_backend = backend

        def _skeptic_call(system: str, user: str) -> str:
            if skeptic_backend == "openrouter" and os.environ.get("OPENROUTER_API_KEY"):
                from openai import OpenAI
                _client = OpenAI(
                    base_url="https://openrouter.ai/api/v1",
                    api_key=os.environ["OPENROUTER_API_KEY"],
                )
                r = _client.chat.completions.create(
                    model="deepseek/deepseek-chat",
                    messages=[{"role": "system", "content": system},
                              {"role": "user", "content": user}],
                    max_tokens=32,
                )
                return r.choices[0].message.content or ""
            else:
                import anthropic
                _client = anthropic.Anthropic()
                r = _client.messages.create(
                    model="claude-sonnet-4-6",
                    system=system,
                    max_tokens=32,
                    messages=[{"role": "user", "content": user}],
                )
                return r.content[0].text if r.content else ""

        # V2.12: cross-vendor skeptic uses 3-vote majority (was single shot in V2.11);
        # same-vendor stays single shot (cheaper, less independent value from repetition).
        _n_votes = 3 if cross_vendor_skeptic else 1
        b1_result = run_b1_inline(result.final_recommendation, _skeptic_call, n_votes=_n_votes)
        # Rule 9 enforcement: if any HALLUCINATED, force confidence cap LOW
        if b1_result["any_hallucinated"]:
            result.confidence = "LOW"

    # V2.15.1 — B.2 inline numeric verifier (default ON; deterministic, $0).
    # Rule 13a mandates show-work, making "<expr> = <number>" pairs extractable.
    # safe_eval recomputes each; a real arithmetic error force-caps confidence LOW.
    b2_result = None
    if verify_math:
        from .b2_inline import run_b2_inline, run_b2_check_lines, build_b2_correction

        def _b2_full(text):
            a, b = run_b2_inline(text), run_b2_check_lines(text)
            a.checks += b.checks
            a.n_checked += b.n_checked
            a.n_error += b.n_error
            return a

        b2_result = _b2_full(result.final_recommendation)
        # V2.19 (exp/72): recompute loop. exp/71/72 showed flagging alone ships the
        # wrong number anyway (confidence LOW doesn't fix the answer) — on a caught
        # arithmetic error, do ONE corrective retry with the computed values, keep
        # the retry only if it verifies cleaner. Deterministic trigger, capped cost.
        if b2_result.any_error:
            _retry_problem = (
                f"{problem}\n\n═══ 你此前的回答 ═══\n{result.final_recommendation}"
                f"\n\n═══ 修正指令 ═══\n{build_b2_correction(b2_result)}"
            )
            try:
                if backend == "openrouter":
                    _fixed, _c2, _i2, _o2 = _call_openrouter(
                        _retry_problem, model or "deepseek/deepseek-chat", max_tokens,
                        system_override=_sys_override)
                else:
                    _fixed, _c2, _i2, _o2 = _call_anthropic(
                        _retry_problem, model or "claude-opus-4-8", max_tokens,
                        system_override=_sys_override)
                _b2_fixed = _b2_full(_fixed)
                if _fixed and _b2_fixed.n_error < b2_result.n_error:
                    result.final_recommendation = _fixed
                    b2_result = _b2_fixed
                    cost += _c2; in_tokens += _i2; out_tokens += _o2
            except Exception:
                pass  # retry is best-effort; the flagged original still ships capped
        if b2_result.any_error:
            result.confidence = "LOW"

    # V2.12 — B.5 codebase-consistency verifier. Closes the loop V2.11 opened:
    # context was fed IN, but nothing verified the recommendation respected it.
    # Auto-runs when codebase context is present (opt-out via verify_consistency=False).
    b5_result = None
    _run_b5 = verify_consistency if verify_consistency is not None else bool(codebase_context)
    if _run_b5 and codebase_context:
        from .b5_consistency import verify_codebase_consistency

        # Prefer a cross-vendor judge when cross_vendor_skeptic is set (independent model).
        _judge_backend = (
            ("anthropic" if backend == "openrouter" else "openrouter")
            if cross_vendor_skeptic else backend
        )

        def _judge_call(system: str, user: str) -> str:
            if _judge_backend == "openrouter" and os.environ.get("OPENROUTER_API_KEY"):
                from openai import OpenAI
                _c = OpenAI(
                    base_url="https://openrouter.ai/api/v1",
                    api_key=os.environ["OPENROUTER_API_KEY"],
                )
                r = _c.chat.completions.create(
                    model="deepseek/deepseek-chat",
                    messages=[{"role": "system", "content": system},
                              {"role": "user", "content": user}],
                    max_tokens=512,
                )
                return r.choices[0].message.content or ""
            elif os.environ.get("ANTHROPIC_API_KEY"):
                import anthropic
                _c = anthropic.Anthropic()
                r = _c.messages.create(
                    model="claude-sonnet-4-6",
                    system=system,
                    max_tokens=512,
                    messages=[{"role": "user", "content": user}],
                )
                return r.content[0].text if r.content else ""
            else:
                # Fall back to the main backend if the cross-vendor key is absent.
                return _call_anthropic(user, "claude-opus-4-8", 512)[0] if backend == "anthropic" \
                    else _call_openrouter(user, "deepseek/deepseek-chat", 512)[0]

        _b5 = verify_codebase_consistency(
            result.final_recommendation, codebase_context, _judge_call
        )
        b5_result = {"verdict": _b5.verdict, "contradictions": _b5.contradictions}
        # Rule 9 enforcement: recommendation contradicts the code reality → cap LOW.
        if _b5.any_contradiction:
            result.confidence = "LOW"

    if verbose:
        tag = f"[{version} / {backend}]"
        if _activation is not None:
            _sc = _activation.scenarios or ["(none — lightweight bare path)"]
            print(f"{tag} adaptive dispatch: activated {_sc}", flush=True)
        print(f"{tag} model={model or 'default'} | confidence={result.confidence} | aw_score={result.aw_score}/12", flush=True)
        if b1_result:
            print(f"{tag} B.1 anchors: {b1_result['n_verified']} VERIFIED / {b1_result['n_hallucinated']} HALLUCINATED of {b1_result['n_anchors']}", flush=True)
            if b1_result["any_hallucinated"]:
                print(f"{tag} Rule 9 ENFORCED → confidence force-capped to LOW", flush=True)
        if b2_result and b2_result.n_checked:
            print(f"{tag} B.2 numeric: {b2_result.n_checked - b2_result.n_error}/{b2_result.n_checked} math checks pass", flush=True)
            for _c in b2_result.checks:
                if not _c.ok:
                    print(f"{tag}   ✗ {_c.expr} → stated {_c.claimed} but computes {round(_c.computed,4)}", flush=True)
            if b2_result.any_error:
                print(f"{tag} Rule 13 ENFORCED → confidence force-capped to LOW (arithmetic error)", flush=True)
        if result.debate_winner != "original":
            print(f"{tag} AW debate replaced original: {result.debate_winner} won", flush=True)
        if result.cluster_a_anchors_used:
            print(f"{tag} Cluster A anchors: {len(result.cluster_a_anchors_used)}", flush=True)
        if result.cluster_d_anchors_used:
            print(f"{tag} Cluster D cultural anchors: {len(result.cluster_d_anchors_used)}", flush=True)
        if result.post_cutoff_flagged:
            print(f"{tag} WARNING: post-cutoff query flagged UNCHECKABLE", flush=True)
        if getattr(result, "estimated_tokens_saved", 0) > 0:
            print(f"{tag} V2.8 alpha gating saved ~{result.estimated_tokens_saved} tokens", flush=True)
        if getattr(result, "ttc_enabled", False):
            print(f"{tag} V2.8 beta TTC: {result.ttc_rounds_run} rounds converged", flush=True)
        if b1_result:
            skeptic_label = "cross-vendor x3" if cross_vendor_skeptic else "same-vendor"
            print(f"{tag} B.1 inline ({skeptic_label}) cost: +~${b1_result['n_anchors'] * 0.001:.4f}", flush=True)
        if codebase_context:
            ctx_len = len(codebase_context)
            print(f"{tag} V2.11 codebase context: {ctx_len} chars injected (file_paths={file_paths}, grep={grep_query}, git_log={git_log})", flush=True)
        if b5_result:
            print(f"{tag} B.5 consistency: {b5_result['verdict']}", flush=True)
            for c in b5_result["contradictions"]:
                print(f"{tag}   ⚠ {c}", flush=True)
            if b5_result["verdict"] == "CONTRADICTIONS_FOUND" and b5_result["contradictions"]:
                print(f"{tag} Rule 9 ENFORCED → confidence force-capped to LOW (code contradiction)", flush=True)
        print(f"{tag} tokens in/out: {in_tokens}/{out_tokens} | cost=${cost:.4f}", flush=True)
        print("---", flush=True)

    if return_dict:
        return {
            "final": result.final_recommendation,
            "confidence": result.confidence,
            "aw_score": result.aw_score,
            "aw_classification": result.aw_classification,
            "debate_triggered": result.debate_triggered,
            "debate_winner": result.debate_winner,
            "cluster_a_anchors": result.cluster_a_anchors_used,
            "cluster_d_anchors": result.cluster_d_anchors_used,
            "post_cutoff_flagged": result.post_cutoff_flagged,
            "cost_usd": cost,
            "tokens_in": in_tokens,
            "tokens_out": out_tokens,
            "backend": backend,
            "model": model or ("deepseek/deepseek-chat" if backend == "openrouter" else "claude-opus-4-8"),
            "codebase_context_chars": len(codebase_context) if codebase_context else 0,
            "cross_vendor_skeptic": cross_vendor_skeptic,
            "b5_consistency": b5_result,
            "version": version,
        }

    return result.final_recommendation


def clarify(problem: str, backend: str = "auto", model: str = None) -> list:
    """V2.25 interactive — clarify gate. Return up to 3 high-leverage questions
    whose answers would change the recommendation, or [] if the problem is
    answerable as-is. Feed the answers back via solve(problem, clarifications=[(q,a),...]).

    Best for open/under-specified advisory questions ("should we do X", "design a
    plan for Y"). exp/85: clarify-then-solve scores 5/8 vs one-shot 0/8 on
    under-specified problems whose hidden fact flips the answer. NOTE the gate
    over-fires on already-answerable questions (numeric / clear pressure) — opt-in
    for advisory use; keep one-shot solve() as the default for specific questions.
    """
    import os
    from .interactive import clarify_gate
    if backend == "auto":
        backend = "openrouter" if os.environ.get("OPENROUTER_API_KEY") else "anthropic"

    def _call(system, user):
        if backend == "openrouter":
            from openai import OpenAI
            c = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=os.environ["OPENROUTER_API_KEY"])
            r = c.chat.completions.create(model=model or "deepseek/deepseek-chat",
                max_tokens=400, temperature=0,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": user}])
            return r.choices[0].message.content or ""
        import anthropic
        r = anthropic.Anthropic().messages.create(model=model or "claude-opus-4-8",
            max_tokens=400, system=system, messages=[{"role": "user", "content": user}])
        return r.content[0].text if r.content else ""

    return clarify_gate(problem, _call)


# V2.12 codebase-reader limits. Unlike V2.11 these are NOT silent: any time a
# limit bites, an explicit note is emitted inline so the model (and the B.5
# consistency verifier) know evidence may be missing — per the "no silent caps"
# principle. Raise them if you need more context and can afford the tokens.
_MAX_FILES = 40            # per-pattern file cap; overflow is reported, not dropped silently
_MAX_FILE_CHARS = 40_000   # per-file char cap; truncation is reported with original size
_MAX_GREP_LINES = 200      # grep line cap; overflow count is reported
_LARGE_FILE_BYTES = 200_000  # files at/above this are still read but flagged as bloat risk


def _git_root(start="."):
    """Return the repo root for `start`, or None if not in a git repo."""
    import subprocess
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=5, cwd=start,
        )
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout.strip()
    except Exception:
        pass
    return None


def _gather_codebase_context(file_paths=None, grep_query=None, git_log=False):
    """V2.12: Gather codebase context from files, grep, and git log.

    Differences from V2.11: NO silent caps — every truncation (file count, file
    size, grep lines) is reported inline. grep/git are anchored to the repo root
    and grep uses `git grep` when available (respects .gitignore, skips binaries).
    """
    import subprocess
    import glob
    from pathlib import Path

    sections = []
    notes = []  # explicit dropped-evidence / truncation reports

    if file_paths:
        for pattern in file_paths:
            matches = sorted(m for m in glob.glob(pattern, recursive=True) if Path(m).is_file())
            if len(matches) > _MAX_FILES:
                dropped = matches[_MAX_FILES:]
                notes.append(
                    f"pattern `{pattern}` matched {len(matches)} files; read first "
                    f"{_MAX_FILES}, DROPPED {len(dropped)}: "
                    + ", ".join(dropped[:10]) + (" …" if len(dropped) > 10 else "")
                )
            for fpath in matches[:_MAX_FILES]:
                p = Path(fpath)
                try:
                    size = p.stat().st_size
                    content = p.read_text(errors="replace")
                    orig_chars = len(content)
                    if size >= _LARGE_FILE_BYTES:
                        notes.append(f"{fpath} is {size:,}B (large) — read but may bloat context")
                    if orig_chars > _MAX_FILE_CHARS:
                        content = content[:_MAX_FILE_CHARS]
                        content += (f"\n… [TRUNCATED at {_MAX_FILE_CHARS:,} of {orig_chars:,} chars "
                                    "— evidence beyond this point NOT shown]")
                    sections.append(f"### FILE: {fpath} ({size:,}B)\n```\n{content}\n```")
                except Exception as e:
                    sections.append(f"### FILE: {fpath}\n[unreadable: {e}]")

    if grep_query:
        root = _git_root()
        try:
            if root:
                # git grep respects .gitignore and skips binaries; anchored to repo root.
                cmd = ["git", "-C", root, "grep", "-nI", grep_query, "--",
                       "*.py", "*.ts", "*.js", "*.md"]
                src = "git grep (respects .gitignore)"
            else:
                cmd = ["grep", "-rnI", "--include=*.py", "--include=*.ts",
                       "--include=*.js", "--include=*.md", grep_query, "."]
                src = "grep"
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            out = (result.stdout or "").strip()
            if out:
                lines = out.split("\n")
                body = "\n".join(lines[:_MAX_GREP_LINES])
                if len(lines) > _MAX_GREP_LINES:
                    extra = len(lines) - _MAX_GREP_LINES
                    body += f"\n… [{extra} MORE matches not shown]"
                    notes.append(f"grep `{grep_query}` had {len(lines)} matches; showing {_MAX_GREP_LINES}")
                sections.append(f"### GREP ({src}): `{grep_query}`\n```\n{body}\n```")
        except Exception:
            pass

    if git_log:
        root = _git_root()
        try:
            cmd = ["git"] + (["-C", root] if root else []) + ["log", "--oneline", "-20"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if (result.stdout or "").strip():
                sections.append(f"### GIT LOG (last 20 commits)\n```\n{result.stdout.strip()}\n```")
        except Exception:
            pass

    if notes:
        sections.insert(
            0,
            "### ⚠ CODEBASE READER NOTES (V2.12 — evidence completeness)\n"
            + "\n".join(f"- {n}" for n in notes),
        )

    return "\n\n".join(sections) if sections else ""


def _call_anthropic(problem, model, max_tokens, system_override=None):
    """Anthropic direct backend."""
    try:
        import anthropic
    except ImportError:
        raise ImportError("pip install anthropic")
    client = anthropic.Anthropic()
    resp = client.messages.create(
        model=model,
        system=system_override or SYSTEM_PROMPT,
        max_tokens=max_tokens,
        messages=[{"role": "user", "content": problem}],
    )
    text = resp.content[0].text
    # Claude Opus pricing: $15/$75 per M
    cost = (resp.usage.input_tokens * 15 + resp.usage.output_tokens * 75) / 1_000_000
    return text, cost, resp.usage.input_tokens, resp.usage.output_tokens


def _call_openrouter(problem, model, max_tokens, system_override=None):
    """OpenRouter backend (DeepSeek default, OpenAI-compatible)."""
    try:
        from openai import OpenAI
    except ImportError:
        raise ImportError("pip install openai  # OpenAI SDK works with OpenRouter")
    import os
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=os.environ["OPENROUTER_API_KEY"],
    )
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_override or SYSTEM_PROMPT},
            {"role": "user", "content": problem},
        ],
        max_tokens=max_tokens,
    )
    msg = resp.choices[0].message
    text = msg.content
    # Reasoning models (deepseek-r1 etc.) may return content=None/"" with the
    # chain-of-thought in `reasoning` — e.g. when max_tokens is exhausted by
    # reasoning before the final answer. Fall back so downstream (auto_score)
    # never receives None; raise loudly if both are empty.
    if not text:
        text = getattr(msg, "reasoning", None) or ""
        if text:
            text = "[reasoning-only output; raise max_tokens for a final answer]\n" + text
    if not text:
        raise RuntimeError(
            f"OpenRouter returned empty content for model={model} "
            f"(finish_reason={resp.choices[0].finish_reason}); "
            "for reasoning models try a larger --max-tokens."
        )
    # DeepSeek-chat via OpenRouter: $0.14/$0.28 per M (very cheap)
    in_tokens = resp.usage.prompt_tokens
    out_tokens = resp.usage.completion_tokens
    pricing = {
        "deepseek/deepseek-chat": (0.14, 0.28),
        "deepseek/deepseek-r1": (0.55, 2.19),
        "anthropic/claude-3.5-sonnet": (3.0, 15.0),
    }
    pin, pout = pricing.get(model, (0.50, 1.50))
    cost = (in_tokens * pin + out_tokens * pout) / 1_000_000
    return text, cost, in_tokens, out_tokens


# Convenience: V2.5+AW system prompt loaded from package data
def _load_prompt() -> str:
    """Load the V2.4.4a canonical reasoning prompt."""
    from pathlib import Path
    prompt_path = Path(__file__).parent / "v2.5_system_prompt.md"
    if prompt_path.exists():
        return prompt_path.read_text()
    return "[V2.4.4a system prompt — see docs/v2.5-system-prompt.md]"


SYSTEM_PROMPT = _load_prompt()
