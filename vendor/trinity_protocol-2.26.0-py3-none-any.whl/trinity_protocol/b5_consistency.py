"""B.5 Codebase-Consistency Verifier (V2.12).

V2.11 opened the codebase dimension — file_paths / grep_query / git_log feed real
source into the prompt context. But V2.11 only verified ANCHORS (citation truth)
via B.1. It had no verifier checking whether the *recommendation* respects the
*code reality* it was handed.

The failure that motivated V2.11 — the SoulMate audit recommending a wrong wire
shape and re-implementing already-shipped code — is a contract/logic error, NOT
an anchor hallucination, so B.1 structurally cannot catch it. Feeding the right
files in is necessary but not sufficient; nothing closed the loop on the output.

B.5 closes that loop: given the recommendation AND the gathered codebase context,
an independent judge flags claims that contradict the shown code or re-propose
something already present. On contradiction, the caller applies Rule 9 and caps
confidence to LOW.

This is an LLM judge (probabilistic), so Rule 12 binary-marker audit does NOT
apply. It only runs when codebase context is non-empty.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

CONSISTENCY_SYSTEM = """You are a codebase-consistency auditor. You are given (1) a RECOMMENDATION and (2) the actual CODEBASE CONTEXT (real source files, grep results, git log) that the recommendation must respect.

Your only job: find claims in the recommendation that CONTRADICT the codebase, or that re-propose something the codebase shows is ALREADY shipped.

Flag these types:
- WRONG_SHAPE: the recommendation describes a function signature, data shape, type, or API that conflicts with what the code actually shows (e.g. recommends a dict when the code uses list[str]).
- ALREADY_EXISTS: the recommendation proposes building something the codebase context shows is already implemented / shipped.
- WRONG_SYMBOL: it references a function/class/file/path that the context shows does not exist or is named differently.
- UNSUPPORTED: it asserts a specific fact about THIS codebase that the provided context neither shows nor mentions.

Rules:
- Only flag when the codebase context actually shows the conflict. Do NOT speculate beyond what is shown.
- If the recommendation is consistent with the shown code, say so.

Reply in EXACTLY this format:
VERDICT: CONSISTENT
or
VERDICT: CONTRADICTIONS_FOUND
followed by one line per issue:
- [TYPE] one-sentence description, citing the file/symbol involved"""


@dataclass
class ConsistencyResult:
    verdict: str  # CONSISTENT / CONTRADICTIONS_FOUND / SKIPPED
    contradictions: list = field(default_factory=list)
    raw: str = ""

    @property
    def any_contradiction(self) -> bool:
        return self.verdict == "CONTRADICTIONS_FOUND" and bool(self.contradictions)


def verify_codebase_consistency(
    recommendation: str,
    codebase_context: str,
    judge_call_fn: Callable[[str, str], str],
    max_context_chars: int = 30_000,
    max_rec_chars: int = 8_000,
) -> ConsistencyResult:
    """Check a recommendation against the gathered codebase context.

    Args:
        recommendation: the solve() output to audit.
        codebase_context: the context gathered by _gather_codebase_context().
        judge_call_fn: (system, user) -> str. Cross-vendor recommended so the
            judge is a different model than the one that wrote the recommendation.
        max_context_chars / max_rec_chars: judge-input caps. Truncation is noted
            to the judge so it knows the view is partial (no silent caps).

    Returns:
        ConsistencyResult. `.any_contradiction` is the Rule 9 trigger.
    """
    if not codebase_context or not codebase_context.strip():
        return ConsistencyResult(verdict="SKIPPED", raw="no codebase context")

    ctx = codebase_context[:max_context_chars]
    ctx_truncated = len(codebase_context) > max_context_chars
    rec = recommendation[:max_rec_chars]
    rec_truncated = len(recommendation) > max_rec_chars

    user = (
        f"RECOMMENDATION:\n{rec}"
        + ("\n… [recommendation truncated for judge]" if rec_truncated else "")
        + f"\n\n═══ CODEBASE CONTEXT ═══\n{ctx}"
        + ("\n… [codebase context truncated for judge — absence of a contradiction "
           "here is not proof of consistency]" if ctx_truncated else "")
    )

    try:
        resp = (judge_call_fn(CONSISTENCY_SYSTEM, user) or "").strip()
    except Exception as e:
        return ConsistencyResult(verdict="SKIPPED", raw=f"judge error: {e}")

    if not resp:
        return ConsistencyResult(verdict="SKIPPED", raw="empty judge response")

    if "CONTRADICTIONS_FOUND" in resp.upper():
        contradictions = [
            ln.strip().lstrip("-").strip()
            for ln in resp.splitlines()
            if ln.strip().startswith("-") and len(ln.strip()) > 3
        ]
        # If the judge declared CONTRADICTIONS_FOUND but listed none, keep the
        # verdict honest rather than silently downgrading to CONSISTENT.
        if not contradictions:
            contradictions = ["[judge flagged contradictions but listed none; review raw output]"]
        return ConsistencyResult(
            verdict="CONTRADICTIONS_FOUND",
            contradictions=contradictions,
            raw=resp[:1500],
        )

    return ConsistencyResult(verdict="CONSISTENT", raw=resp[:1500])
