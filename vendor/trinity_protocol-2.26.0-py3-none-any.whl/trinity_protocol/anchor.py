"""Trinity Protocol V2.5 Anchor Verifier — reference implementation.

Reads a V2.4+ trace markdown file, extracts every Practitioner anchor it cites,
verifies each one with an independent fresh Claude session that has web access,
and writes a structured JSON audit + a markdown patch for docs/AUDIT-LEDGER.md.

Usage:
    python verifier.py path/to/experiments/NN-trace.md

Requires:
    - ANTHROPIC_API_KEY env var set
    - anthropic Python SDK (pip install anthropic)
    - Claude model with web_search tool available (default: claude-opus-4-8)

Output:
    <trace>.audit.json  — structured per-anchor verdict
    <trace>.audit.md    — human-readable summary
    Prints to stdout the AUDIT-LEDGER.md patch to apply.

Design notes:
    - Step 1 (extract) has NO tools; reads only the markdown, returns JSON.
    - Step 2 (verify) is one Claude call PER anchor, with web_search tool, in a
      fresh session each time. Independence is enforced by passing only the
      single anchor claim — no Trinity context, no other anchors, no trace text.
    - Quote-or-refuse: VERIFIED requires a URL or verbatim quoted text from the
      tool-augmented session. If the verifier returns VERIFIED without one,
      the wrapper downgrades to PARTIAL VERIFIED and flags for review.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

try:
    import anthropic
except ImportError:
    sys.exit("Install the anthropic SDK first: pip install anthropic")


DEFAULT_MODEL = "claude-opus-4-8"
EXTRACT_TEMPERATURE = 0.0
VERIFY_TEMPERATURE = 0.0
MAX_SEARCHES_PER_ANCHOR = 3


EXTRACT_PROMPT = """You are reading a Trinity Protocol V2.4 trace. Extract every Practitioner-section anchor cited.

For each anchor, identify:
  - source: the named entity/document/person being cited (verbatim from the trace)
  - datum: the specific claim or data point attributed to that source (verbatim or close paraphrase)
  - gate: which V2.4 gate the anchor supports (Feasibility / Simplicity / Honesty / Reduction / PST / ExecutionDetail / Trinity1-Practitioner)
  - location: approximate section heading in the trace (for traceability)

Anchors typically appear in Trinity 1 Practitioner subsection and in Gate 5 (PST) or Gate 6 (Execution Detail) cells. Each numbered Practitioner source is one anchor. Each row in a Gate 6 table is one anchor.

Return ONLY a JSON array of objects with keys [source, datum, gate, location]. No prose. No markdown fences. Pure JSON.

Trace to extract from:
---
{trace_text}
---
"""


VERIFY_PROMPT = """You are an independent fact-checker. Audit one citation claim for whether it can be verified to public-source standard.

Classify on this ladder (return EXACTLY one):
  VERIFIED        — You produced a URL OR verbatim quote OR specific page/section reference; source AND datum check out.
  PARTIAL_VERIFIED — Source exists, correctly named; datum is loose OR framing overstates the source's normative force.
  PLAUSIBLE       — Source class real + datum dimensionally reasonable; you could NOT retrieve specific supporting text.
  MISMATCHED      — Source exists but the cited document/journal/section is wrong type; data wouldn't normally live there.
  HALLUCINATED    — Source itself does not exist OR named person wrong-attributed OR specific quote fabricated.
  UNCHECKABLE     — Source named but inherently unverifiable (private channels, proprietary documents).

Rules:
  - Use up to 3 web searches.
  - Do NOT default to VERIFIED without retrieved evidence.
  - For VERIFIED or PARTIAL_VERIFIED, you MUST quote verbatim supporting text from a source. No quote → not VERIFIED.
  - For MISMATCHED or HALLUCINATED, explain specifically what is wrong (wrong-org / wrong-person / wrong-document-type / non-existent).
  - Propose ONE adversarial alternative interpretation that, if the source IS real, might contradict the claim.

Return ONLY JSON with keys:
  classification    — one of the six labels above
  evidence          — URL(s) found + verbatim quote(s) (empty if HALLUCINATED)
  searches          — list of queries you issued
  what_you_found    — concise description of search results
  alt_interpretation — one alternative reading
  notes             — anything else worth flagging

Anchor to audit:
  Source: {source}
  Datum: {datum}
  (Context: this is from a problem-solving framework citation; you do NOT need to know what the problem is.)
"""


@dataclass
class Anchor:
    source: str
    datum: str
    gate: str
    location: str


@dataclass
class Verdict:
    anchor: Anchor
    classification: str
    evidence: str
    searches: list[str]
    what_you_found: str
    alt_interpretation: str
    notes: str

    def as_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["anchor"] = asdict(self.anchor)
        return d


def extract_anchors(client: anthropic.Anthropic, trace_text: str, model: str) -> list[Anchor]:
    """Step 1 — Claude reads trace, returns JSON list of anchor claims. No tools."""
    response = client.messages.create(
        model=model,
        max_tokens=4096,
        temperature=EXTRACT_TEMPERATURE,
        messages=[{"role": "user", "content": EXTRACT_PROMPT.format(trace_text=trace_text)}],
    )
    text = response.content[0].text.strip()
    # Strip optional markdown fence the model might add anyway
    if text.startswith("```"):
        text = text.split("\n", 1)[1]
        if text.endswith("```"):
            text = text.rsplit("```", 1)[0]
        text = text.strip()
        if text.startswith("json"):
            text = text[4:].strip()
    raw = json.loads(text)
    return [Anchor(**item) for item in raw]


def verify_anchor(client: anthropic.Anthropic, anchor: Anchor, model: str) -> Verdict:
    """Step 2 — fresh Claude session per anchor, with web_search tool."""
    response = client.messages.create(
        model=model,
        max_tokens=4096,
        temperature=VERIFY_TEMPERATURE,
        tools=[{"type": "web_search_20250305", "name": "web_search", "max_uses": MAX_SEARCHES_PER_ANCHOR}],
        messages=[{"role": "user", "content": VERIFY_PROMPT.format(source=anchor.source, datum=anchor.datum)}],
    )
    # Walk through tool-use loop and harvest the final JSON
    text_parts = [block.text for block in response.content if hasattr(block, "text")]
    final_text = "\n".join(text_parts).strip()
    # Strip code fence if present
    if final_text.startswith("```"):
        final_text = final_text.split("\n", 1)[1]
        if final_text.endswith("```"):
            final_text = final_text.rsplit("```", 1)[0]
        final_text = final_text.strip()
        if final_text.startswith("json"):
            final_text = final_text[4:].strip()
    try:
        payload = json.loads(final_text)
    except json.JSONDecodeError:
        # Verifier didn't return clean JSON. Fail loud rather than guess.
        payload = {
            "classification": "PLAUSIBLE",
            "evidence": "",
            "searches": [],
            "what_you_found": f"Verifier did not return parseable JSON. Raw: {final_text[:400]}",
            "alt_interpretation": "",
            "notes": "VERIFIER_PARSE_FAILED — manual review required.",
        }
    # Anti-hallucination safeguard: VERIFIED without quoted evidence → downgrade
    if payload["classification"] == "VERIFIED" and not payload.get("evidence", "").strip():
        payload["classification"] = "PARTIAL_VERIFIED"
        payload["notes"] = (payload.get("notes") or "") + " [downgraded: VERIFIED without quote/URL]"
    return Verdict(anchor=anchor, **payload)


def render_summary_md(verdicts: list[Verdict], trace_path: Path) -> str:
    """Step 3 — human-readable per-trace audit summary."""
    by_class: dict[str, int] = {}
    for v in verdicts:
        by_class[v.classification] = by_class.get(v.classification, 0) + 1

    n = len(verdicts)
    verified = by_class.get("VERIFIED", 0)
    partial = by_class.get("PARTIAL_VERIFIED", 0)
    hallucinated = by_class.get("HALLUCINATED", 0)
    rate = (verified / n * 100) if n else 0.0

    lines = [
        f"# V2.5 Verifier Audit — {trace_path.name}",
        "",
        f"**Anchors audited**: {n}",
        f"**VERIFIED**: {verified} ({rate:.0f}%)",
        f"**PARTIAL_VERIFIED**: {partial}",
        f"**HALLUCINATED**: {hallucinated}",
        f"**Other**: {n - verified - partial - hallucinated}",
        "",
        "## Per-anchor verdicts",
        "",
        "| # | Source | Classification | Evidence / Notes |",
        "|---|--------|---------------|------------------|",
    ]
    for i, v in enumerate(verdicts, 1):
        src_raw = (v.anchor.source[:60] + "…") if len(v.anchor.source) > 60 else v.anchor.source
        src_cell = src_raw.replace("|", "\\|")
        note_short = (v.notes or v.what_you_found or "")[:160]
        ev_short = (v.evidence[:120] + "…") if len(v.evidence) > 120 else v.evidence
        cell = (ev_short or note_short).replace("\n", " ").replace("|", "\\|")
        lines.append(f"| {i} | {src_cell} | {v.classification} | {cell} |")
    return "\n".join(lines) + "\n"


def render_ledger_patch(verdicts: list[Verdict], trace_path: Path) -> str:
    """Step 4 — patch fragment for docs/AUDIT-LEDGER.md (caller applies manually for now)."""
    trace_id = trace_path.stem
    today = "VERIFIER-RUN"  # replaced by run script with date in CI
    lines = [
        f"### Trace `experiments/{trace_id}` — V2.5 verifier run ({today})",
        "",
        "| Anchor | Status | Verified by | Date | Note |",
        "|--------|--------|------------|------|------|",
    ]
    for v in verdicts:
        src_raw = (v.anchor.source[:80] + "…") if len(v.anchor.source) > 80 else v.anchor.source
        src_cell = src_raw.replace("|", "\\|")
        note = (v.notes or v.what_you_found or "")[:120].replace("|", "\\|").replace("\n", " ")
        lines.append(f"| {src_cell} | {v.classification} | tools/v2.5-verifier | {today} | {note} |")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Trinity Protocol V2.5 anchor verifier")
    parser.add_argument("trace", type=Path, help="Path to V2.4+ trace markdown")
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"Anthropic model (default: {DEFAULT_MODEL})")
    parser.add_argument("--output-dir", type=Path, default=None, help="Where to write .audit.json / .audit.md (default: alongside trace)")
    parser.add_argument("--sleep", type=float, default=0.5, help="Sleep between per-anchor verify calls (seconds)")
    args = parser.parse_args()

    if not args.trace.exists():
        sys.exit(f"Trace not found: {args.trace}")
    if not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("ANTHROPIC_API_KEY is not set.")

    output_dir = args.output_dir or args.trace.parent
    audit_json = output_dir / f"{args.trace.stem}.audit.json"
    audit_md = output_dir / f"{args.trace.stem}.audit.md"
    ledger_patch = output_dir / f"{args.trace.stem}.ledger-patch.md"

    client = anthropic.Anthropic()
    trace_text = args.trace.read_text()

    print(f"[1/3] Extracting anchors from {args.trace.name} ...", file=sys.stderr)
    anchors = extract_anchors(client, trace_text, args.model)
    print(f"      Found {len(anchors)} anchors.", file=sys.stderr)

    verdicts: list[Verdict] = []
    for i, anchor in enumerate(anchors, 1):
        print(f"[2/3] Verifying anchor {i}/{len(anchors)}: {anchor.source[:60]}...", file=sys.stderr)
        verdict = verify_anchor(client, anchor, args.model)
        verdicts.append(verdict)
        print(f"      → {verdict.classification}", file=sys.stderr)
        if i < len(anchors):
            time.sleep(args.sleep)

    print(f"[3/3] Writing outputs to {output_dir} ...", file=sys.stderr)
    audit_json.write_text(json.dumps([v.as_dict() for v in verdicts], indent=2))
    audit_md.write_text(render_summary_md(verdicts, args.trace))
    ledger_patch.write_text(render_ledger_patch(verdicts, args.trace))

    print(f"      {audit_json.name}", file=sys.stderr)
    print(f"      {audit_md.name}", file=sys.stderr)
    print(f"      {ledger_patch.name}", file=sys.stderr)
    print(f"\nVERIFIED: {sum(1 for v in verdicts if v.classification == 'VERIFIED')}/{len(verdicts)}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
